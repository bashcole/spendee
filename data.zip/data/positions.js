export default [
    {
        units: 32.78984,
        avg_open: 74.47826,
        note: "To The Moon!",
        currency: "GME",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-02-05T21:00:00.000Z"
    },
    {
        units: 96.98,
        avg_open: 11.7066,
        note: "To The Moon!",
        currency: "ETC",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-02-11T21:00:00.000Z"
    },
    {
        units: 1618.10,
        avg_open: 1.29229,
        note: "To The Moon!",
        currency: "ADA",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-02-11T21:00:00.000Z"
    },
    {
        units: 0.36,
        avg_open: 2917.3384,
        note: "To The Moon!",
        currency: "ETH",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-05-02T21:00:00.000Z"
    },
    {
        units: 6842.30,
        avg_open: 0.12083,
        note: "To The Moon!",
        currency: "TRX",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-04-15T21:00:00.000Z"
    },
    {
        units: 89.14,
        avg_open: 5.6093,
        note: "To The Moon!",
        currency: "XTZ",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-05-02T21:00:00.000Z"
    },
    {
        units: 328.77,
        avg_open: 1.81224,
        note: "To The Moon!",
        currency: "MIOTA",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-05-02T21:00:00.000Z"
    },
    {
        units: 0.14,
        avg_open: 178.90,
        note: "To The Moon!",
        currency: "LTC",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17fc9ee46236763ddb",
        createdAt: "2021-05-02T21:00:00.000Z"
    },
    {
        units: 10,
        avg_open: 168.394,
        note: "To The Moon!",
        currency: "LTC",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17bc5e3cce092af15d",
        createdAt: "2021-08-18T21:00:00.000Z"
    },
    {
        units: 0.7646,
        avg_open: 3007,
        note: "To The Moon!",
        currency: "ETH",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17bc5e3cce092af15d",
        createdAt: "2021-08-18T21:00:00.000Z"
    },
    {
        units: 0.05186,
        avg_open: 44541.65059,
        note: "To The Moon!",
        currency: "BTC",
        userID: "6273a061a5d8d48855ff4b6e",
        walletID: "6273af17bc5e3cce092af15d",
        createdAt: "2021-08-18T21:00:00.000Z"
    }
]