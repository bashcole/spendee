import bcrypt from "bcryptjs"

export default [
  {
    "_id": "6273a061a5d8d48855ff4b6e",
    "email": "war1an91@gmail.com",
    "name": "Marian Petrov",
    "username": "marian",
    "password": bcrypt.hashSync('vaflaSpoko123', 10)
  },
  {
    "_id": "6273a0733d3f7b2af9320b24",
    "email": "example@gmail.com",
    "name": "Sandbox",
    "username": "sandbox",
    "password": bcrypt.hashSync('123456', 10)
  }
]