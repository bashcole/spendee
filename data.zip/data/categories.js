export default [
    {
        "_id": "6273a1b78d8262e2fd1fc8f5",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "income",
        "name": "Подаръци",
        "color": "#f5534b",
        "icon": "gift.svg"
    },
    {
        "_id": "6273a1b7fc756e7f8669c5a2",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "income",
        "name": "Заплата",
        "color": "#71c643",
        "icon": "money.svg"
    },
    {
        "_id": "6273a1b793f0a5ab2c4c98ae",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "income",
        "name": "Extra",
        "color": "#ffa200",
        "icon": "shopping.svg"
    },
    {
        "_id": "6273a1b7e6330d4afc010683",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Храна",
        "color": "#b47b55",
        "icon": "grocery.svg"
    },
    {
        "_id": "6273a1b75f1ef59bd22fae00",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Забавления",
        "color": "#f963a0",
        "icon": "entertainment.svg"
    },
    {
        "_id": "6273a1b741cfb9d40ff5e940",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Транспорт",
        "color": "#61708c",
        "icon": "transport.svg"
    },
    {
        "_id": "6273a1b71c6a03fdae63e5cc",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Подаръци",
        "color": "#f5534b",
        "icon": "gift.svg"
    },
    {
        "_id": "6273a1b7aab68cf6f25c2d05",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Сметки",
        "color": "#71c643",
        "icon": "money.svg"
    },
    {
        "_id": "6273a1b7e7196c377f9adc33",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Пътешествия",
        "color": "#47a7e6",
        "icon": "plane.svg"
    },
    {
        "_id": "6273a1b7f2a7b83ba6f58ab5",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Пазаруване",
        "color": "#5dc6ad",
        "icon": "shopping.svg"
    },
    {
        "_id": "6273a1b703010727438dec3c",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "iTunes",
        "color": "#71c643",
        "icon": "itunes.svg"
    },
    {
        "_id": "6273a1b79c10d47371278253",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Наем",
        "color": "#71c643",
        "icon": "rent.svg"
    },
    {
        "_id": "6273a1b7ef84d07e5ee3bc6b",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Здраве",
        "color": "#e56274",
        "icon": "healthcare.svg"
    },
    {
        "_id": "6273a1b7b29f59e3aec037be",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Заведения",
        "color": "#f963a0",
        "icon": "food.svg"
    },
    {
        "_id": "6273a1b7b162dfc06894be13",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Хотели",
        "color": "#47a7e6",
        "icon": "acommodation.svg"
    },
    {
        "_id": "6273a1b743e703a8192f06b8",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Спорт",
        "color": "#47a7e6",
        "icon": "gym.svg"
    },
    {
        "_id": "6273a1b70692bd104073be61",
        "userID": "6273a061a5d8d48855ff4b6e",
        "type": "expense",
        "name": "Приравняване",
        "color": "#f5534b",
        "icon": "wallets.svg"
    },
    {
        "_id": "6273a1b7ae265ae64bd66a3b",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "income",
        "name": "Подаръци",
        "color": "#f5534b",
        "icon": "gift.svg"
    },
    {
        "_id": "6273a1b7a03b186ea4bce77c",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "income",
        "name": "Заплата",
        "color": "#71c643",
        "icon": "money.svg"
    },
    {
        "_id": "6273a1b7f22d1fb549e1ef8c",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "income",
        "name": "Extra",
        "color": "#ffa200",
        "icon": "shopping.svg"
    },
    {
        "_id": "6273a1b75d90ae1cb86925bf",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Храна",
        "color": "#b47b55",
        "icon": "grocery.svg"
    },
    {
        "_id": "6273a1b71dfda20e8c136f79",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Забавления",
        "color": "#f963a0",
        "icon": "entertainment.svg"
    },
    {
        "_id": "6273a1b7ece353dd99acf9b6",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Транспорт",
        "color": "#61708c",
        "icon": "transport.svg"
    },
    {
        "_id": "6273a1b7190b14c379cf142a",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Подаръци",
        "color": "#f5534b",
        "icon": "gift.svg"
    },
    {
        "_id": "6273a1b7edbb92f6e0628fbf",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Сметки",
        "color": "#71c643",
        "icon": "money.svg"
    },
    {
        "_id": "6273a1b74294e47422832e6c",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Пътешествия",
        "color": "#47a7e6",
        "icon": "plane.svg"
    },
    {
        "_id": "6273a1b7d1f98a3081376261",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Пазаруване",
        "color": "#5dc6ad",
        "icon": "shopping.svg"
    },
    {
        "_id": "6273a1b7df9dba191382de8e",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "iTunes",
        "color": "#71c643",
        "icon": "itunes.svg"
    },
    {
        "_id": "6273a1b7352554e284d4298a",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Наем",
        "color": "#71c643",
        "icon": "rent.svg"
    },
    {
        "_id": "6273a1b7126ed403851d6af2",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Здраве",
        "color": "#e56274",
        "icon": "healthcare.svg"
    },
    {
        "_id": "6273a1b71adf66d973541459",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Заведения",
        "color": "#f963a0",
        "icon": "food.svg"
    },
    {
        "_id": "6273a1b75d49a06d23659d75",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Хотели",
        "color": "#47a7e6",
        "icon": "acommodation.svg"
    },
    {
        "_id": "6273a1b74c00738cb6ac3fc7",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Спорт",
        "color": "#47a7e6",
        "icon": "gym.svg"
    },
    {
        "_id": "6273a1b7b3a1c4b1afaf5285",
        "userID": "6273a0733d3f7b2af9320b24",
        "type": "expense",
        "name": "Приравняване",
        "color": "#f5534b",
        "icon": "wallets.svg"
    }
]