export default [
    {
        "_id": "6273af17e3e50dfafa2f2940",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "Utility Fond",
        "balance": 0,
        "currency": "BGN"
    },
    {
        "_id": "6273af170df0dfbaacd24235",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "Invest Fond",
        "balance": 0,
        "currency": "BGN"
    },
    {
        "_id": "6273af17fc9ee46236763ddb",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "Etoro",
        "balance": 0,
        "currency": "USD",
        "type": "portfolio",
        "otherCurrency": {
            "balance": 0,
            "currency": "BGN"
        }
    },
    {
        "_id": "6273af17bc5e3cce092af15d",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "Ledger Live",
        "balance": 0,
        "currency": "USD",
        "type": "portfolio",
        "otherCurrency": {
            "balance": 0,
            "currency": "BGN"
        }
    },
    {
        "_id": "6273af174d6d4f98f09d3493",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "Euro Fond",
        "balance": 0,
        "currency": "EUR",
        "otherCurrency": {
            "balance": 0,
            "currency": "BGN"
        }
    },
    {
        "_id": "6273af17d6da08ae55a4e478",
        "userID": "6273a061a5d8d48855ff4b6e",
        "name": "UniCredit Bulbank",
        "balance": 0,
        "currency": "BGN"
    },
    {
        "_id": "6273af17db9b0ff00d1b3051",
        "userID": "6273a0733d3f7b2af9320b24",
        "name": "Central Cooperative Bank",
        "balance": 0,
        "currency": "BGN"
    },
    {
        "_id": "6273af17cc74d3185aa55eac",
        "userID": "6273a0733d3f7b2af9320b24",
        "name": "Utility Fond",
        "balance": 0,
        "currency": "BGN"
    },
    {
        "_id": "6273af1767ed6544c5c75589",
        "userID": "6273a0733d3f7b2af9320b24",
        "name": "Invest Fond",
        "balance": 0,
        "currency": "EUR",
        "otherCurrency": {
            "balance": 0,
            "currency": "BGN"
        }
    }
]