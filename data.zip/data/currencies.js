export default [{
    name: "Cardano",
    ticker: "ADA",
    type: "crypto",
    coin_id: "cardano"
}, {
    name: "United Arab Emirates Dirham",
    ticker: "AED",
    type: "fiat"
}, {
    name: "Afghan afghani",
    ticker: "AFN",
    type: "fiat"
}, {
    name: "Albanian lek",
    ticker: "ALL",
    type: "fiat"
}, {
    name: "Armenian dram",
    ticker: "AMD",
    type: "fiat"
}, {
    name: "Netherlands Antillean Guilder",
    ticker: "ANG",
    type: "fiat"
}, {
    name: "Angolan kwanza",
    ticker: "AOA",
    type: "fiat"
}, {
    name: "Argentine peso",
    ticker: "ARS",
    type: "fiat"
}, {
    name: "Australian dollar",
    ticker: "AUD",
    type: "fiat"
}, {
    name: "Aruban florin",
    ticker: "AWG",
    type: "fiat"
}, {
    name: "Azerbaijani manat",
    ticker: "AZN",
    type: "fiat"
}, {
    name: "Bosnia-Herzegovina Convertible Mark",
    ticker: "BAM",
    type: "fiat"
}, {
    name: "Bajan dollar",
    ticker: "BBD",
    type: "fiat"
}, {
    name: "Bitcoin Cash",
    ticker: "BCH",
    type: "crypto",
    coin_id: "bitcoin-cash"
}, {
    name: "Bangladeshi taka",
    ticker: "BDT",
    type: "fiat"
}, {
    name: "Bulgarian lev",
    ticker: "BGN",
    symbol: "лв",
    symbolPosition: "right",
    type: "fiat"
}, {
    name: "Bahraini dinar",
    ticker: "BHD",
    type: "fiat"
}, {
    name: "Burundian Franc",
    ticker: "BIF",
    type: "fiat"
}, {
    name: "Bermudan dollar",
    ticker: "BMD",
    type: "fiat"
}, {
    name: "Binance Coin",
    ticker: "BNB",
    type: "crypto",
    coin_id: "binancecoin"
}, {
    name: "Brunei dollar",
    ticker: "BND",
    type: "fiat"
}, {
    name: "Bolivian boliviano",
    ticker: "BOB",
    type: "fiat"
}, {
    name: "Brazilian real",
    ticker: "BRL",
    type: "fiat"
}, {
    name: "Bahamian dollar",
    ticker: "BSD",
    type: "fiat"
}, {
    name: "Bitcoin",
    ticker: "BTC",
    type: "crypto",
    coin_id: "bitcoin"
}, {
    name: "Bhutan currency",
    ticker: "BTN",
    type: "fiat"
}, {
    name: "Botswanan Pula",
    ticker: "BWP",
    type: "fiat"
}, {
    name: "New Belarusian Ruble",
    ticker: "BYN",
    type: "fiat"
}, {
    name: "Belarusian Ruble",
    ticker: "BYR",
    type: "fiat"
}, {
    name: "Belize dollar",
    ticker: "BZD",
    type: "fiat"
}, {
    name: "Canadian dollar",
    ticker: "CAD",
    type: "fiat"
}, {
    name: "Congolese franc",
    ticker: "CDF",
    type: "fiat"
}, {
    name: "Swiss franc",
    ticker: "CHF",
    type: "fiat"
}, {
    name: "Chilean Unit of Account (UF)",
    ticker: "CLF",
    type: "fiat"
}, {
    name: "Chilean peso",
    ticker: "CLP",
    type: "fiat"
}, {
    name: "Chinese Yuan",
    ticker: "CNY",
    type: "fiat"
}, {
    name: "Colombian peso",
    ticker: "COP",
    type: "fiat"
}, {
    name: "Costa Rican Colón",
    ticker: "CRC",
    type: "fiat"
}, {
    name: "Cuban peso",
    ticker: "CUC",
    type: "fiat"
}, {
    name: "Cuban Peso",
    ticker: "CUP",
    type: "fiat"
}, {
    name: "Cape Verdean escudo",
    ticker: "CVE",
    type: "fiat"
}, {
    name: "Czech koruna",
    ticker: "CZK",
    type: "fiat"
}, {
    name: "Djiboutian franc",
    ticker: "DJF",
    type: "fiat"
}, {
    name: "Danish krone",
    ticker: "DKK",
    type: "fiat"
}, {
    name: "Dogecoin",
    ticker: "DOGE",
    type: "crypto",
    coin_id: "dogecoin"
}, {
    name: "IOTA",
    ticker: "MIOTA",
    type: "crypto",
    coin_id: "iota"
}, {
    name: "Tezos",
    ticker: "XTZ",
    type: "crypto",
    coin_id: "tezos"
}, {
    name: "Dominican peso",
    ticker: "DOP",
    type: "fiat"
}, {
    name: "Algerian dinar",
    ticker: "DZD",
    type: "fiat"
}, {
    name: "Egyptian pound",
    ticker: "EGP",
    type: "fiat"
}, {
    name: "Eritrean nakfa",
    ticker: "ERN",
    type: "fiat"
}, {
    name: "Ethiopian birr",
    ticker: "ETB",
    type: "fiat"
}, {
    name: "Ethereum Classic",
    ticker: "ETC",
    type: "crypto",
    coin_id: "ethereum-classic"
}, {
    name: "Ether",
    ticker: "ETH",
    type: "crypto",
    coin_id: "ethereum"
}, {
    name: "Euro",
    ticker: "EUR",
    symbol: "€",
    symbolPosition: "left",
    type: "fiat"
}, {
    name: "Fijian dollar",
    ticker: "FJD",
    type: "fiat"
}, {
    name: "Falkland Islands pound",
    ticker: "FKP",
    type: "fiat"
}, {
    name: "Pound sterling",
    ticker: "GBP",
    type: "fiat"
}, {
    name: "Georgian lari",
    ticker: "GEL",
    type: "fiat"
}, {
    name: "GGPro",
    ticker: "GGP",
    type: "fiat"
}, {
    name: "Ghanaian cedi",
    ticker: "GHS",
    type: "fiat"
}, {
    name: "Gibraltar pound",
    ticker: "GIP",
    type: "fiat"
}, {
    name: "Gambian dalasi",
    ticker: "GMD",
    type: "fiat"
}, {
    name: "Guinean franc",
    ticker: "GNF",
    type: "fiat"
}, {
    name: "Guatemalan quetzal",
    ticker: "GTQ",
    type: "fiat"
}, {
    name: "Guyanaese Dollar",
    ticker: "GYD",
    type: "fiat"
}, {
    name: "Hong Kong dollar",
    ticker: "HKD",
    type: "fiat"
}, {
    name: "Honduran lempira",
    ticker: "HNL",
    type: "fiat"
}, {
    name: "Croatian kuna",
    ticker: "HRK",
    type: "fiat"
}, {
    name: "Haitian gourde",
    ticker: "HTG",
    type: "fiat"
}, {
    name: "Hungarian forint",
    ticker: "HUF",
    type: "fiat"
}, {
    name: "Indonesian rupiah",
    ticker: "IDR",
    type: "fiat"
}, {
    name: "Israeli New Shekel",
    ticker: "ILS",
    type: "fiat"
}, {
    name: "CoinIMP",
    ticker: "IMP",
    type: "fiat"
}, {
    name: "Indian rupee",
    ticker: "INR",
    type: "fiat"
}, {
    name: "Iraqi dinar",
    ticker: "IQD",
    type: "fiat"
}, {
    name: "Iranian rial",
    ticker: "IRR",
    type: "fiat"
}, {
    name: "Icelandic króna",
    ticker: "ISK",
    type: "fiat"
}, {
    name: "Jersey Pound",
    ticker: "JEP",
    type: "fiat"
}, {
    name: "Jamaican dollar",
    ticker: "JMD",
    type: "fiat"
}, {
    name: "Jordanian dinar",
    ticker: "JOD",
    type: "fiat"
}, {
    name: "Japanese yen",
    ticker: "JPY",
    type: "fiat"
}, {
    name: "Kenyan shilling",
    ticker: "KES",
    type: "fiat"
}, {
    name: "Kyrgystani Som",
    ticker: "KGS",
    type: "fiat"
}, {
    name: "Cambodian riel",
    ticker: "KHR",
    type: "fiat"
}, {
    name: "Comorian franc",
    ticker: "KMF",
    type: "fiat"
}, {
    name: "North Korean won",
    ticker: "KPW",
    type: "fiat"
}, {
    name: "South Korean won",
    ticker: "KRW",
    type: "fiat"
}, {
    name: "Kuwaiti dinar",
    ticker: "KWD",
    type: "fiat"
}, {
    name: "Cayman Islands dollar",
    ticker: "KYD",
    type: "fiat"
}, {
    name: "Kazakhstani tenge",
    ticker: "KZT",
    type: "fiat"
}, {
    name: "Laotian Kip",
    ticker: "LAK",
    type: "fiat"
}, {
    name: "Lebanese pound",
    ticker: "LBP",
    type: "fiat"
}, {
    name: "Sri Lankan rupee",
    ticker: "LKR",
    type: "fiat"
}, {
    name: "Liberian dollar",
    ticker: "LRD",
    type: "fiat"
}, {
    name: "Lesotho loti",
    ticker: "LSL",
    type: "fiat"
}, {
    name: "Litecoin",
    ticker: "LTC",
    type: "crypto",
    coin_id: "litecoin"
}, {
    name: "Lithuanian litas",
    ticker: "LTL",
    type: "fiat"
}, {
    name: "Latvian lats",
    ticker: "LVL",
    type: "fiat"
}, {
    name: "Libyan dinar",
    ticker: "LYD",
    type: "fiat"
}, {
    name: "Moroccan dirham",
    ticker: "MAD",
    type: "fiat"
}, {
    name: "Moldovan leu",
    ticker: "MDL",
    type: "fiat"
}, {
    name: "Malagasy ariary",
    ticker: "MGA",
    type: "fiat"
}, {
    name: "Macedonian denar",
    ticker: "MKD",
    type: "fiat"
}, {
    name: "Myanmar Kyat",
    ticker: "MMK",
    type: "fiat"
}, {
    name: "Mongolian tugrik",
    ticker: "MNT",
    type: "fiat"
}, {
    name: "Macanese pataca",
    ticker: "MOP",
    type: "fiat"
}, {
    name: "Mauritanian ouguiya",
    ticker: "MRO",
    type: "fiat"
}, {
    name: "Mauritian rupee",
    ticker: "MUR",
    type: "fiat"
}, {
    name: "Maldivian rufiyaa",
    ticker: "MVR",
    type: "fiat"
}, {
    name: "Malawian kwacha",
    ticker: "MWK",
    type: "fiat"
}, {
    name: "Mexican peso",
    ticker: "MXN",
    type: "fiat"
}, {
    name: "Malaysian ringgit",
    ticker: "MYR",
    type: "fiat"
}, {
    name: "Mozambican Metical",
    ticker: "MZN",
    type: "fiat"
}, {
    name: "Namibian dollar",
    ticker: "NAD",
    type: "fiat"
}, {
    name: "Nigerian naira",
    ticker: "NGN",
    type: "fiat"
}, {
    name: "Nicaraguan córdoba",
    ticker: "NIO",
    type: "fiat"
}, {
    name: "Norwegian krone",
    ticker: "NOK",
    type: "fiat"
}, {
    name: "Nepalese rupee",
    ticker: "NPR",
    type: "fiat"
}, {
    name: "New Zealand dollar",
    ticker: "NZD",
    type: "fiat"
}, {
    name: "Omani rial",
    ticker: "OMR",
    type: "fiat"
}, {
    name: "Panamanian balboa",
    ticker: "PAB",
    type: "fiat"
}, {
    name: "Sol",
    ticker: "PEN",
    type: "fiat"
}, {
    name: "Papua New Guinean kina",
    ticker: "PGK",
    type: "fiat"
}, {
    name: "Philippine peso",
    ticker: "PHP",
    type: "fiat"
}, {
    name: "Pakistani rupee",
    ticker: "PKR",
    type: "fiat"
}, {
    name: "Poland złoty",
    ticker: "PLN",
    type: "fiat"
}, {
    name: "Paraguayan guarani",
    ticker: "PYG",
    type: "fiat"
}, {
    name: "Qatari Rial",
    ticker: "QAR",
    type: "fiat"
}, {
    name: "Romanian leu",
    ticker: "RON",
    type: "fiat"
}, {
    name: "Serbian dinar",
    ticker: "RSD",
    type: "fiat"
}, {
    name: "Russian ruble",
    ticker: "RUB",
    type: "fiat"
}, {
    name: "Rwandan Franc",
    ticker: "RWF",
    type: "fiat"
}, {
    name: "Saudi riyal",
    ticker: "SAR",
    type: "fiat"
}, {
    name: "Solomon Islands dollar",
    ticker: "SBD",
    type: "fiat"
}, {
    name: "Seychellois rupee",
    ticker: "SCR",
    type: "fiat"
}, {
    name: "Sudanese pound",
    ticker: "SDG",
    type: "fiat"
}, {
    name: "Swedish krona",
    ticker: "SEK",
    type: "fiat"
}, {
    name: "Singapore dollar",
    ticker: "SGD",
    type: "fiat"
}, {
    name: "Saint Helena pound",
    ticker: "SHP",
    type: "fiat"
}, {
    name: "Sierra Leonean leone",
    ticker: "SLL",
    type: "fiat"
}, {
    name: "Somali shilling",
    ticker: "SOS",
    type: "fiat"
}, {
    name: "Surinamese dollar",
    ticker: "SRD",
    type: "fiat"
}, {
    name: "São Tomé and Príncipe Dobra (pre-2018)",
    ticker: "STD",
    type: "fiat"
}, {
    name: "Salvadoran Colón",
    ticker: "SVC",
    type: "fiat"
}, {
    name: "Syrian pound",
    ticker: "SYP",
    type: "fiat"
}, {
    name: "Swazi lilangeni",
    ticker: "SZL",
    type: "fiat"
}, {
    name: "Thai baht",
    ticker: "THB",
    type: "fiat"
}, {
    name: "Tajikistani somoni",
    ticker: "TJS",
    type: "fiat"
}, {
    name: "Turkmenistani manat",
    ticker: "TMT",
    type: "fiat"
}, {
    name: "Tunisian dinar",
    ticker: "TND",
    type: "fiat"
}, {
    name: "Tongan Paʻanga",
    ticker: "TOP",
    type: "fiat"
}, {
    name: "TRON",
    ticker: "TRX",
    type: "crypto",
    coin_id: "tron"
}, {
    name: "Turkish lira",
    ticker: "TRY",
    type: "fiat"
}, {
    name: "Trinidad &amp; Tobago Dollar",
    ticker: "TTD",
    type: "fiat"
}, {
    name: "New Taiwan dollar",
    ticker: "TWD",
    type: "fiat"
}, {
    name: "Tanzanian shilling",
    ticker: "TZS",
    type: "fiat"
}, {
    name: "Ukrainian hryvnia",
    ticker: "UAH",
    type: "fiat"
}, {
    name: "Ugandan shilling",
    ticker: "UGX",
    type: "fiat"
}, {
    name: "United States dollar",
    ticker: "USD",
    symbol: "$",
    symbolPosition: "left",
    type: "fiat"
}, {
    name: "Uruguayan peso",
    ticker: "UYU",
    type: "fiat"
}, {
    name: "Uzbekistani som",
    ticker: "UZS",
    type: "fiat"
}, {
    name: "Sovereign Bolivar",
    ticker: "VEF",
    type: "fiat"
}, {
    name: "Vietnamese dong",
    ticker: "VND",
    type: "fiat"
}, {
    name: "Vanuatu vatu",
    ticker: "VUV",
    type: "fiat"
}, {
    name: "Samoan tala",
    ticker: "WST",
    type: "fiat"
}, {
    name: "Central African CFA franc",
    ticker: "XAF",
    type: "fiat"
}, {
    name: "Silver Ounce",
    ticker: "XAG",
    type: "fiat"
}, {
    name: "XauCoin",
    ticker: "XAU",
    type: "fiat"
}, {
    name: "East Caribbean dollar",
    ticker: "XCD",
    type: "fiat"
}, {
    name: "Special Drawing Rights",
    ticker: "XDR",
    type: "fiat"
}, {
    name: "Stellar",
    ticker: "XLM",
    type: "crypto",
    coin_id: "stellar"
}, {
    name: "Monero",
    ticker: "XMR",
    type: "crypto",
    coin_id: "monero"
}, {
    name: "West African CFA franc",
    ticker: "XOF",
    type: "fiat"
}, {
    name: "CFP franc",
    ticker: "XPF",
    type: "fiat"
}, {
    name: "XRP",
    ticker: "XRP",
    type: "crypto",
    coin_id: "ripple"
}, {
    name: "Yemeni rial",
    ticker: "YER",
    type: "fiat"
}, {
    name: "South African rand",
    ticker: "ZAR",
    type: "fiat"
}, {
    name: "Zambian kwacha",
    ticker: "ZMK",
    type: "fiat"
}, {
    name: "Zambian Kwacha",
    ticker: "ZMW",
    type: "fiat"
}, {
    name: "Zimbabwean Dollar",
    ticker: "ZWL",
    type: "fiat"
}, {
    name: "Tesla Motors, Inc.",
    ticker: "TSLA",
    type: "stock"
}, {
    name: "Amazon.com Inc",
    ticker: "AMZN",
    type: "stock"
}, {
    name: "Apple",
    ticker: "AAPL",
    type: "stock"
}, {
    name: "Meta Platforms Inc",
    ticker: "FB",
    type: "stock"
}, {
    name: "Microsoft",
    ticker: "MSFT",
    type: "stock"
}, {
    name: "Alibaba",
    ticker: "BABA",
    type: "stock"
}, {
    name: "NVIDIA Corporation",
    ticker: "NVDA",
    type: "stock"
}, {
    name: "Alphabet",
    ticker: "GOOG",
    type: "stock"
}, {
    name: "Nio Inc.",
    ticker: "NIO",
    type: "stock"
}, {
    name: "PayPal Holdings",
    ticker: "PYPL",
    type: "stock"
}, {
    name: "Netflix, Inc.",
    ticker: "NFLX",
    type: "stock"
}, {
    name: "Netflix, Inc.",
    ticker: "NFLX",
    type: "stock"
}, {
    name: "Advanced Micro Devices Inc",
    ticker: "AMD",
    type: "stock"
}, {
    name: "Walt Disney",
    ticker: "DIS",
    type: "stock"
}, {
    name: "Visa",
    ticker: "V",
    type: "stock"
}, {
    name: "GameStop Corp.",
    ticker: "GME",
    type: "stock"
}, {
    name: "Mastercard",
    ticker: "MA",
    type: "stock"
}, {
    name: "Airbnb Inc",
    ticker: "ABNB",
    type: "stock"
}, {
    name: "Twitter",
    ticker: "TWTR",
    type: "stock"
}, {
    name: "NIKE",
    ticker: "NIKE",
    type: "stock"
}]