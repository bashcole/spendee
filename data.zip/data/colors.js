export default [
    {
        "_id": "6273a23d7f19eef5fcc99c1b",
        "hex": "#f5534b"
    },
    {
        "_id": "6273a23d74eca700e0ea558b",
        "hex": "#b55a42"
    },
    {
        "_id": "6273a23dc088e6961aa19046",
        "hex": "#b47b55"
    },
    {
        "_id": "6273a23d8b68a7a846fcefc0",
        "hex": "#d35e00"
    },
    {
        "_id": "6273a23de6a2be11a5cb56ff",
        "hex": "#de8135"
    },
    {
        "_id": "6273a23dfb3ff962f380e16b",
        "hex": "#df8c29"
    },
    {
        "_id": "6273a23df5ffcb6af0587745",
        "hex": "#b9965e"
    },
    {
        "_id": "6273a23d0c954c8341f44ebe",
        "hex": "#ffa200"
    },
    {
        "_id": "6273a23d279da12c4bffce8a",
        "hex": "#ffa800"
    },
    {
        "_id": "6273a23dc870f56b1aca6325",
        "hex": "#ffcc00"
    },
    {
        "_id": "6273a23d16c78ae7d00c294d",
        "hex": "#bed940"
    },
    {
        "_id": "6273a23dd0fa4b1432682bde",
        "hex": "#71c643"
    },
    {
        "_id": "6273a23d1b0bfeb3cfd01385",
        "hex": "#18b272"
    },
    {
        "_id": "6273a23d2de644a7018073e3",
        "hex": "#5cc5ac"
    },
    {
        "_id": "6273a23dd44a6d44b524c4e3",
        "hex": "#60cfcb"
    },
    {
        "_id": "6273a23dcf26f0b63c786223",
        "hex": "#1eadce"
    },
    {
        "_id": "6273a23d50d30e9eb5d95e21",
        "hex": "#1a94ca"
    },
    {
        "_id": "6273a23d914fa2e4490f2b6f",
        "hex": "#47a7e6"
    },
    {
        "_id": "6273a23de7852dd01328a038",
        "hex": "#3d75ab"
    },
    {
        "_id": "6273a23dc62565524560c7b9",
        "hex": "#659dd6"
    },
    {
        "_id": "6273a23d92abf6d40862e9f0",
        "hex": "#6e8cb1"
    },
    {
        "_id": "6273a23d53358bfb59b0ac12",
        "hex": "#66686b"
    },
    {
        "_id": "6273a23d3024cbbab546fcd9",
        "hex": "#61708c"
    },
    {
        "_id": "6273a23d5277b8dd9933a434",
        "hex": "#6d6e89"
    },
    {
        "_id": "6273a23d69a96c885c36cf40",
        "hex": "#7945d0"
    },
    {
        "_id": "6273a23d245712ee1ef6f84c",
        "hex": "#e26beb"
    },
    {
        "_id": "6273a23d62d4988b42671ca9",
        "hex": "#f963a0"
    },
    {
        "_id": "6273a23d299dc7c8c0735e82",
        "hex": "#e56274"
    },
    {
        "_id": "6273a23d835fa79416491297",
        "hex": "#5dc6ad"
    },
    {
        "_id": "6273a23d68113cedd80199b7",
        "hex": "#b47b55"
    }
]