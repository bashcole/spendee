import dotenv from "dotenv"

dotenv.config()

export default [{
    "amount": 184943,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Init",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-07-08T05:49:50.000Z"
}, {
    "amount": 120000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-07-08T05:49:50.000Z"
}, {
    "amount": 120000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-08-08T05:52:48.000Z"
}, {
    "amount": 1972,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода - 8 кубика",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-09-06T16:24:04.000Z"
}, {
    "amount": 120000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-09-08T05:53:59.000Z"
}, {
    "amount": 12000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2016-09-08T10:10:29.000Z"
}, {
    "amount": 3723,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Кашкавал Родопея (0.755 грама) - 7.40лв Пилешко филе (0.970 грама) - 8.15лв Яйца (12 бр) - 2.28лв Круши и Банани (907 грама, 1.75 кг) - 5.88лв Краставици (1.3 кг) - 2.70лв Домат (1 кг) - 1лв Салата (1 бр) - 0.70лв Пушен врат (1.341 кг) - 9.12лв  Общо:  37",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2016-09-08T16:13:58.000Z"
}, {
    "amount": 12180,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "1TB HGST Touro Mobile, външен хард диск",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-09-09T06:19:55.000Z"
}, {
    "amount": 6800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Apple Battery charger",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-09-11T06:34:28.000Z"
}, {
    "amount": 1255,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "OLX кредити",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-09-13T09:53:35.000Z"
}, {
    "amount": 291700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2016-09-21T16:12:44.000Z"
}, {
    "amount": 6842,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Tinder plus",
    "category": {
        "type": "credit",
        "name": "iTunes",
        "id": "6273a1b703010727438dec3c",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/itunes.svg`
    },
    "createdAt": "2016-09-26T06:30:18.000Z"
}, {
    "amount": 120000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-10-08T05:54:17.000Z"
}, {
    "amount": 29000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Общи неща",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-10-12T10:03:31.000Z"
}, {
    "amount": 11100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2016-10-13T10:10:03.000Z"
}, {
    "amount": 14000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "+ други неща",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2016-10-18T10:08:29.000Z"
}, {
    "amount": 3409,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "10 x ( My Size 57-60mm )",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-10-20T09:51:42.000Z"
}, {
    "amount": 8800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Габриела",
    "category": {
        "type": "credit",
        "name": "Хотели",
        "id": "6273a1b7b162dfc06894be13",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/acommodation.svg`
    },
    "createdAt": "2016-11-06T10:43:51.000Z"
}, {
    "amount": 130000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-11-08T07:57:11.000Z"
}, {
    "amount": 29900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Четка за лице - след 3 месеца да се смени приставката",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2016-11-28T11:44:59.000Z"
}, {
    "amount": 130000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2016-12-08T07:57:35.000Z"
}, {
    "amount": 20000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Коледен бонус",
    "category": {
        "type": "debit",
        "name": "Подаръци",
        "id": "6273a1b78d8262e2fd1fc8f5",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2016-12-08T07:58:34.000Z"
}, {
    "amount": 102400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2016-12-08T12:12:05.000Z"
}, {
    "amount": 15844,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Заради срещата с Тина и други момичета",
    "category": {
        "type": "credit",
        "name": "Хотели",
        "id": "6273a1b7b162dfc06894be13",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/acommodation.svg`
    },
    "createdAt": "2016-12-15T10:43:23.000Z"
}, {
    "amount": 53700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2016-12-30T12:07:41.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Януари месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-01-01T08:40:08.000Z"
}, {
    "amount": 20000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "H&M дрехи и обувки",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-01-04T09:55:11.000Z"
}, {
    "amount": 6644,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Weetabix",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-01-05T10:36:42.000Z"
}, {
    "amount": 130000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Януари месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-01-08T08:00:46.000Z"
}, {
    "amount": 4500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Плевен - за да се даде проба",
    "category": {
        "type": "credit",
        "name": "Хотели",
        "id": "6273a1b7b162dfc06894be13",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/acommodation.svg`
    },
    "createdAt": "2017-01-10T10:45:17.000Z"
}, {
    "amount": 6849,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "BDSM комплект",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-01-10T10:46:12.000Z"
}, {
    "amount": 19500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "L-OptiZinc Vitamin D-3 5000 UI Ultra Omega-3 Fish O",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-01-15T10:35:46.000Z"
}, {
    "amount": 4213,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-01-21T17:58:32.000Z"
}, {
    "amount": 6990,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Тиган",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-01-22T10:46:48.000Z"
}, {
    "amount": 4911,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-01-23T18:00:48.000Z"
}, {
    "amount": 12067,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "H&M  Кецове Чаршаф Комплект",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-01-25T10:48:31.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-02-01T08:40:37.000Z"
}, {
    "amount": 3322,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-02-04T18:19:12.000Z"
}, {
    "amount": 6180,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Pjur back door 100ml x 2 Lubido 250ml",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-02-07T10:49:09.000Z"
}, {
    "amount": 7271,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Газ",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-02-07T11:46:56.000Z"
}, {
    "amount": 130000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-02-08T08:03:00.000Z"
}, {
    "amount": 161200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2017-02-28T18:11:39.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Март месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-03-01T08:42:01.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Март месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-03-01T08:57:06.000Z"
}, {
    "amount": 15000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-11T12:09:06.000Z"
}, {
    "amount": 1380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-03-12T11:54:55.000Z"
}, {
    "amount": 36795,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Светло синя риза, бежав чино панталон и бели кецове",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-03-15T10:49:55.000Z"
}, {
    "amount": 5484,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-16T12:01:35.000Z"
}, {
    "amount": 6000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бели обувки",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-03-16T12:01:59.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "По-светли чино",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-03-16T18:00:21.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Светло синя риза",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-03-16T18:02:10.000Z"
}, {
    "amount": 2450,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком интернет и мобилен интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-03-17T18:21:54.000Z"
}, {
    "amount": 30978,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Дрехи",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-03-18T10:51:15.000Z"
}, {
    "amount": 6992,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-19T11:58:44.000Z"
}, {
    "amount": 3643,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-21T18:08:22.000Z"
}, {
    "amount": 1700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Еднократно посещение + еспадрили",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2017-03-23T10:59:43.000Z"
}, {
    "amount": 2198,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел интернет - София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-03-25T18:22:51.000Z"
}, {
    "amount": 2200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-03-27T16:22:22.000Z"
}, {
    "amount": 3537,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-29T16:18:06.000Z"
}, {
    "amount": 3220,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-03-29T16:20:20.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-04-01T06:42:18.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-04-01T06:57:51.000Z"
}, {
    "amount": 6380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-04-01T09:59:22.000Z"
}, {
    "amount": 9145,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла: храна + ел.четка - около 45лв",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-04-03T08:52:52.000Z"
}, {
    "amount": 5127,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-04-05T15:59:37.000Z"
}, {
    "amount": 29900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обектив Nikon AF-S DX Nikkor 35mm f/1.8G",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-04-11T06:17:23.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-05-01T06:45:30.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-05-01T07:00:40.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-06-01T06:45:53.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-06-01T07:01:12.000Z"
}, {
    "amount": 140000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бонус 1400 за операцията",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-01T07:07:27.000Z"
}, {
    "amount": 6203,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Transmit 4 license",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-02T08:54:19.000Z"
}, {
    "amount": 13517,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Храна, препарати и 2 ножчета за бръснене",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-06-03T10:02:58.000Z"
}, {
    "amount": 24200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Презервативи х 2 Анален Воден Лубрикант х 2 Tenga Flip Zero Мастурбатор",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-06T08:55:07.000Z"
}, {
    "amount": 5565,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Weetabix x 6",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-07T08:55:50.000Z"
}, {
    "amount": 3890,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-06-08T16:03:26.000Z"
}, {
    "amount": 127000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2017-06-09T16:10:48.000Z"
}, {
    "amount": 23940,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Екипировка за катерене плус сак за фитнес",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-10T09:01:01.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Еднодневен пропуск за катерене",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2017-06-10T16:23:28.000Z"
}, {
    "amount": 1380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-06-11T09:55:26.000Z"
}, {
    "amount": 3594,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-06-11T16:15:35.000Z"
}, {
    "amount": 7998,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-06-15T09:57:51.000Z"
}, {
    "amount": 4161,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток, вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-06-18T16:01:28.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Plovdiv Guide",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-06-21T07:08:50.000Z"
}, {
    "amount": 6049,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-06-22T10:01:05.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-07-01T06:47:02.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-07-01T07:09:15.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-08-01T06:47:43.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-08-01T07:18:28.000Z"
}, {
    "amount": 39000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Годишна карта за Атлетик Фитнес",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2017-08-28T09:02:30.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-09-01T06:48:15.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-09-01T07:19:22.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-10-01T06:49:50.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-10-01T07:19:44.000Z"
}, {
    "amount": 11125,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "12 Weetabix boxes",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-10-05T09:03:10.000Z"
}, {
    "amount": 7995,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чадър от MassimoDutti",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-10-09T09:04:16.000Z"
}, {
    "amount": 49500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Camel Coat",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-10-10T09:43:29.000Z"
}, {
    "amount": 4683,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-10-10T15:57:28.000Z"
}, {
    "amount": 6084,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-10-11T10:00:24.000Z"
}, {
    "amount": 1380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-10-13T09:55:47.000Z"
}, {
    "amount": 100000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Plovdiv guide",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2017-10-14T07:21:59.000Z"
}, {
    "amount": 1351,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Такси до УНСС",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2017-10-14T09:54:20.000Z"
}, {
    "amount": 8786,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-10-16T09:56:24.000Z"
}, {
    "amount": 2558,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-10-16T16:21:23.000Z"
}, {
    "amount": 22000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Осигуровки: 2015: 9, 10, 11, 12 2016: 1, 2, 3, 4, 5, 6, 7, 8",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2017-10-19T06:27:57.000Z"
}, {
    "amount": 7015,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2017-10-24T09:58:20.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-11-01T08:50:23.000Z"
}, {
    "amount": 200000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-11-01T09:50:33.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2017-12-01T08:50:49.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2017-12-01T09:51:22.000Z"
}, {
    "amount": 14117,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-01-05T11:46:01.000Z"
}, {
    "amount": 6600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "20 х FitSpo slim",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-08T11:06:53.000Z"
}, {
    "amount": 5107,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-08T17:59:56.000Z"
}, {
    "amount": 10420,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "2 x SOMNTUTA чаршаф с ластик",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-01-09T11:08:57.000Z"
}, {
    "amount": 3738,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-09T18:03:01.000Z"
}, {
    "amount": 2640,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "FitSpo x 8",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-01-15T18:08:59.000Z"
}, {
    "amount": 3295,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-15T18:19:34.000Z"
}, {
    "amount": 10260,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ластик Training 50 кг х 2, Ластик Training 15 кг х 2, Ластик Training 25 кг х 2",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-01-16T11:10:01.000Z"
}, {
    "amount": 4529,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-21T17:57:56.000Z"
}, {
    "amount": 5878,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел, Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-01-22T11:47:41.000Z"
}, {
    "amount": 3300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "FitSpo x 10",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-01-23T11:52:18.000Z"
}, {
    "amount": 3348,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-29T18:18:51.000Z"
}, {
    "amount": 3953,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-01-30T18:02:35.000Z"
}, {
    "amount": 3492,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-02-05T18:14:25.000Z"
}, {
    "amount": 7000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Слушалки за телефона",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-02-06T11:11:37.000Z"
}, {
    "amount": 30838,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Max Size and Max Shred",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-03-10T11:44:07.000Z"
}, {
    "amount": 216200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2018-03-11T18:12:12.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-04-01T07:44:22.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-04-04T07:41:45.000Z"
}, {
    "amount": 11434,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергас",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-04-08T09:12:28.000Z"
}, {
    "amount": 3616,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-04-08T16:14:58.000Z"
}, {
    "amount": 2143,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-04-12T16:25:26.000Z"
}, {
    "amount": 2146,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-04-16T16:24:57.000Z"
}, {
    "amount": 6173,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-04-20T09:59:59.000Z"
}, {
    "amount": 5875,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел и Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-04-22T09:49:04.000Z"
}, {
    "amount": 5438,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток и вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-04-23T10:06:39.000Z"
}, {
    "amount": 1799,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "H&M (underware)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-04-30T09:15:22.000Z"
}, {
    "amount": 4895,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "LC WAIKIKI (shirts)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-04-30T09:23:09.000Z"
}, {
    "amount": 3389,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-04-30T16:06:07.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-05-01T07:42:03.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-05-01T07:43:53.000Z"
}, {
    "amount": 4200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-05-03T15:58:51.000Z"
}, {
    "amount": 3145,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-05-04T16:20:48.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-06-01T07:46:36.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-06-10T18:00:00.000Z"
}, {
    "amount": 60636,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Добавки от sila.bg",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-12T18:00:00.000Z"
}, {
    "amount": 680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": " Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-13T18:00:00.000Z"
}, {
    "amount": 5886,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": " Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-06-14T18:00:00.000Z"
}, {
    "amount": 39,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "1.5 вода от Лидл",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-17T18:00:00.000Z"
}, {
    "amount": 1791,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-18T18:00:00.000Z"
}, {
    "amount": 143100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "GoPro + accessories",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-18T18:00:00.000Z"
}, {
    "amount": 5840,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Рамен",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-06-20T18:00:00.000Z"
}, {
    "amount": 2522,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-06-20T18:00:00.000Z"
}, {
    "amount": 720,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-21T18:00:00.000Z"
}, {
    "amount": 2004,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-06-23T18:00:00.000Z"
}, {
    "amount": 18985,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Massimo Dutti",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-23T18:00:00.000Z"
}, {
    "amount": 3578,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "A1 два телефона и интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-06-24T18:00:00.000Z"
}, {
    "amount": 2466,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-06-24T18:00:00.000Z"
}, {
    "amount": 1813,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-06-24T18:00:00.000Z"
}, {
    "amount": 3211,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-06-25T18:00:00.000Z"
}, {
    "amount": 535,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-06-25T18:00:00.000Z"
}, {
    "amount": 6990,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Парфюм",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-06-27T18:00:00.000Z"
}, {
    "amount": 2505,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-06-28T18:00:00.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-07-10T18:00:00.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-08-10T18:00:00.000Z"
}, {
    "amount": 388700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2018-08-10T18:00:00.000Z"
}, {
    "amount": 3225,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-10T18:00:00.000Z"
}, {
    "amount": 1287,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-13T18:00:00.000Z"
}, {
    "amount": 715,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-13T18:00:00.000Z"
}, {
    "amount": 10182,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-15T18:00:00.000Z"
}, {
    "amount": 14487,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла, Лидл, Фантастико",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-20T18:00:00.000Z"
}, {
    "amount": 2883,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-08-20T18:00:00.000Z"
}, {
    "amount": 2846,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пици в Уго на Витошка",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-08-20T18:00:00.000Z"
}, {
    "amount": 72,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Материали за гривната",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-08-20T18:00:00.000Z"
}, {
    "amount": 270,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Домати от кв.Лозенец",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-08-20T18:00:00.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-08-31T18:00:00.000Z"
}, {
    "amount": 580000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август, плус за операцията",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-10T18:00:00.000Z"
}, {
    "amount": 72632,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2018-09-10T18:00:00.000Z"
}, {
    "amount": 1400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-12T18:00:00.000Z"
}, {
    "amount": 3358,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл: Прясно пилешко филе х 6, лук",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-13T18:00:00.000Z"
}, {
    "amount": 2922,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл: Прясно пилешко филе х 6, солети х 3",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-13T18:00:00.000Z"
}, {
    "amount": 882,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла: хляб, биволска луканка, яйца",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-13T18:00:00.000Z"
}, {
    "amount": 1000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "McDonald's",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 1980,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "2night Bar & Garden",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро, 10бр",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 1695,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 178,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фантастико",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 549,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl - пилешко филе",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 25,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl - 500мл вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-14T18:00:00.000Z"
}, {
    "amount": 11790,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zara",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-15T08:30:00.000Z"
}, {
    "amount": 17695,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Massimo Dutti",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-15T09:00:00.000Z"
}, {
    "amount": 4995,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Massimo Dutti",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-16T08:44:57.000Z"
}, {
    "amount": 800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Зоологическа градина",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2018-09-16T08:44:35.000Z"
}, {
    "amount": 2995,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-16T08:45:29.000Z"
}, {
    "amount": 758,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-18T03:41:18.000Z"
}, {
    "amount": 985,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-18T03:41:49.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Карзил",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-09-18T05:44:47.000Z"
}, {
    "amount": 69,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl - боза",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-18T05:45:04.000Z"
}, {
    "amount": 923,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-19T06:44:25.000Z"
}, {
    "amount": 4995,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zara - полувер",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-23T05:11:09.000Z"
}, {
    "amount": 2529,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-23T05:12:18.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро, 10бр",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-09-23T05:12:38.000Z"
}, {
    "amount": 260,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Starbucks Coffee",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-23T05:13:18.000Z"
}, {
    "amount": 6000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mr. Pizza",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-23T05:13:38.000Z"
}, {
    "amount": 350,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чушки",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-23T05:13:58.000Z"
}, {
    "amount": 1065,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-23T05:14:52.000Z"
}, {
    "amount": 3700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фея",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-23T11:16:15.000Z"
}, {
    "amount": 946,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-23T11:16:35.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Карзил макс",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-24T07:19:35.000Z"
}, {
    "amount": 2700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-24T07:19:58.000Z"
}, {
    "amount": 3578,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-24T07:20:37.000Z"
}, {
    "amount": 1020,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода за пиене",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-24T11:05:42.000Z"
}, {
    "amount": 2100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Отиване връщане София-Червен бряг, Плевен",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-09-25T14:48:22.000Z"
}, {
    "amount": 500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "газ за бутилката - червен бряг",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-25T14:48:59.000Z"
}, {
    "amount": 397,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "неща от левчето",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-09-25T14:49:20.000Z"
}, {
    "amount": 210,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Биллата",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-25T14:49:40.000Z"
}, {
    "amount": 3588,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток, вода и т.н",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-09-26T13:15:42.000Z"
}, {
    "amount": 40000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Годишна карта валидна до 25 Ноември 2019",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-09-26T05:41:52.000Z"
}, {
    "amount": 1293,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-26T13:12:05.000Z"
}, {
    "amount": 1077,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-09-28T07:29:27.000Z"
}, {
    "amount": 2500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Рамен, вода, торта",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-09-29T04:56:02.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-10-01T05:35:02.000Z"
}, {
    "amount": 700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Потници от Бабала",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-04T13:06:11.000Z"
}, {
    "amount": 1250,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-05T12:46:38.000Z"
}, {
    "amount": 3173,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-06T06:28:48.000Z"
}, {
    "amount": 3990,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обувки от DEICHMANN",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-06T06:29:33.000Z"
}, {
    "amount": 1373,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Overgas",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-10-06T08:21:27.000Z"
}, {
    "amount": 1350,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София <=> Червен бряг",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-10-07T14:08:37.000Z"
}, {
    "amount": 190,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Банани",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-08T03:17:46.000Z"
}, {
    "amount": 605,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Магазина на Тамара",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-08T14:15:41.000Z"
}, {
    "amount": 347,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-09T14:17:15.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета за Мом",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-09T14:20:11.000Z"
}, {
    "amount": 2387,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-10T05:22:32.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cleancare Cleanser",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-10T14:19:35.000Z"
}, {
    "amount": 105,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-11T14:17:34.000Z"
}, {
    "amount": 2778,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-12T03:11:13.000Z"
}, {
    "amount": 650,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг <=> Плевен",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-10-12T14:09:18.000Z"
}, {
    "amount": 222,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-12T14:18:21.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета за Мом",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-13T14:20:52.000Z"
}, {
    "amount": 300000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-10-14T11:05:04.000Z"
}, {
    "amount": 896,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-14T11:03:53.000Z"
}, {
    "amount": 2884,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-14T11:04:38.000Z"
}, {
    "amount": 7520,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Уагамама",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-10-14T06:16:55.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-15T10:57:44.000Z"
}, {
    "amount": 462,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-16T07:50:56.000Z"
}, {
    "amount": 597,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-16T08:01:16.000Z"
}, {
    "amount": 480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-17T07:24:09.000Z"
}, {
    "amount": 885,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-17T07:25:46.000Z"
}, {
    "amount": 349,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-17T09:55:20.000Z"
}, {
    "amount": 2458,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-18T09:55:37.000Z"
}, {
    "amount": 2145,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-19T09:59:15.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета за Мом",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-19T09:59:56.000Z"
}, {
    "amount": 1553,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-19T10:00:22.000Z"
}, {
    "amount": 680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-19T12:48:40.000Z"
}, {
    "amount": 2426,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-20T10:28:41.000Z"
}, {
    "amount": 1957,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-22T09:44:53.000Z"
}, {
    "amount": 1572,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-22T09:45:11.000Z"
}, {
    "amount": 2656,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Vivacom",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-10-23T12:20:51.000Z"
}, {
    "amount": 3578,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "A1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-10-23T12:21:26.000Z"
}, {
    "amount": 99,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-23T12:22:16.000Z"
}, {
    "amount": 23398,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Myprotein Impact Whey Isolate от readyforlife ",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-24T07:44:49.000Z"
}, {
    "amount": 1729,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-24T11:23:16.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета за Мом (Карзил Макс)",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-24T11:24:05.000Z"
}, {
    "amount": 1384,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-24T11:24:29.000Z"
}, {
    "amount": 762,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-25T11:49:05.000Z"
}, {
    "amount": 680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-25T03:46:20.000Z"
}, {
    "amount": 1847,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-25T11:49:32.000Z"
}, {
    "amount": 3716,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-10-26T10:30:07.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пица от Victoria",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-26T09:43:36.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Карзил Макс",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-10-27T10:11:38.000Z"
}, {
    "amount": 1738,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Дар",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-27T10:12:26.000Z"
}, {
    "amount": 396,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-27T10:12:58.000Z"
}, {
    "amount": 1854,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-27T10:13:27.000Z"
}, {
    "amount": 387,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-28T13:35:53.000Z"
}, {
    "amount": 680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-10-29T13:17:26.000Z"
}, {
    "amount": 57,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-30T05:59:24.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 10 пътувания",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-10-31T08:09:34.000Z"
}, {
    "amount": 3754,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-10-31T08:09:55.000Z"
}, {
    "amount": 1629,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-01T11:00:35.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-01T02:25:43.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-11-01T07:40:28.000Z"
}, {
    "amount": 800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mr. Pizza x 3",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-01T14:43:05.000Z"
}, {
    "amount": 747,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла - мармалади",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-03T09:54:33.000Z"
}, {
    "amount": 685,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-03T12:52:04.000Z"
}, {
    "amount": 650,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг <=> Плевен",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-11-08T07:54:08.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "платен преглед Янев",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-11-08T08:22:59.000Z"
}, {
    "amount": 5719,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-09T11:46:29.000Z"
}, {
    "amount": 2550,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Overgas",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-09T11:47:25.000Z"
}, {
    "amount": 1088,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "капки за очи",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-11-09T08:21:00.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mr. Pizza",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2018-11-10T18:30:18.000Z"
}, {
    "amount": 966,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-11T07:52:05.000Z"
}, {
    "amount": 393,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-11T07:51:33.000Z"
}, {
    "amount": 749,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-11T07:45:51.000Z"
}, {
    "amount": 971,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-13T14:05:41.000Z"
}, {
    "amount": 2529,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-13T14:06:01.000Z"
}, {
    "amount": 3564,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-15T14:49:21.000Z"
}, {
    "amount": 249,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-15T14:49:49.000Z"
}, {
    "amount": 5187,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сумамед и други хапчета",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-11-15T14:50:36.000Z"
}, {
    "amount": 5696,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-17T07:57:17.000Z"
}, {
    "amount": 5995,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zarra - панталон",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-18T10:31:35.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Happy",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2018-11-18T04:18:53.000Z"
}, {
    "amount": 535,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-19T09:22:24.000Z"
}, {
    "amount": 714,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-19T09:22:40.000Z"
}, {
    "amount": 1000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Скъсяване на панталон",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-19T10:32:23.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода и курабии",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-20T09:22:19.000Z"
}, {
    "amount": 4459,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-20T15:51:17.000Z"
}, {
    "amount": 1865,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-21T10:38:32.000Z"
}, {
    "amount": 1582,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-21T16:36:24.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "ластаци -3бр. Sport-Depo",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-11-21T16:39:28.000Z"
}, {
    "amount": 531,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "фантастико",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-21T16:38:11.000Z"
}, {
    "amount": 4369,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-22T14:19:02.000Z"
}, {
    "amount": 1380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел - телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-22T14:19:52.000Z"
}, {
    "amount": 2678,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Vivacom",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-22T14:20:27.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета на Мом - Карзил",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-11-23T14:17:30.000Z"
}, {
    "amount": 636,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-23T14:17:51.000Z"
}, {
    "amount": 288,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-23T14:18:43.000Z"
}, {
    "amount": 2198,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мтел - интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-23T14:19:21.000Z"
}, {
    "amount": 26650,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Reebok Legacy Lifter - Green",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-11-23T17:25:21.000Z"
}, {
    "amount": 1516,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-24T14:10:52.000Z"
}, {
    "amount": 491,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-24T14:11:10.000Z"
}, {
    "amount": 4500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Paradise Mall - обувки",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-24T14:11:36.000Z"
}, {
    "amount": 4170,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бабала",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-24T14:11:54.000Z"
}, {
    "amount": 16704,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "RPM jumping rope and other stuff",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-11-24T05:41:34.000Z"
}, {
    "amount": 397,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-25T13:50:53.000Z"
}, {
    "amount": 775,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-25T13:51:10.000Z"
}, {
    "amount": 10254,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Осигоровки до края на 2018",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-11-25T13:51:40.000Z"
}, {
    "amount": 3634,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-26T14:12:28.000Z"
}, {
    "amount": 21,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Намерени в фитнеса",
    "category": {
        "type": "debit",
        "name": "Подаръци",
        "id": "6273a1b78d8262e2fd1fc8f5",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2018-11-27T05:37:48.000Z"
}, {
    "amount": 317,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-27T13:51:48.000Z"
}, {
    "amount": 2322,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-27T13:52:15.000Z"
}, {
    "amount": 1085,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-28T15:13:28.000Z"
}, {
    "amount": 290000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "CVIC - Moodle",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-29T15:10:24.000Z"
}, {
    "amount": 2400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "DHL цесия",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-30T07:09:34.000Z"
}, {
    "amount": 100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "MegaCopy",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-11-30T07:10:14.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 12бр",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-11-30T07:10:36.000Z"
}, {
    "amount": 2356,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-30T07:10:55.000Z"
}, {
    "amount": 5584,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-11-30T07:11:48.000Z"
}, {
    "amount": 300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Такси - клепарник до DHL",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-11-30T07:54:09.000Z"
}, {
    "amount": 3840,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "е-подпис",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-11-30T06:01:22.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2018-12-01T07:40:42.000Z"
}, {
    "amount": 186,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-01T08:17:19.000Z"
}, {
    "amount": 1248,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-01T08:17:40.000Z"
}, {
    "amount": 60,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Принтиране",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-01T08:18:41.000Z"
}, {
    "amount": 1350,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "БДЖ - София - Червен бряг",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-12-02T05:32:52.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 10 пътувания",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-12-03T05:01:36.000Z"
}, {
    "amount": 25,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Принтиране",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-03T13:43:18.000Z"
}, {
    "amount": 600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Нотариус",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-03T05:59:39.000Z"
}, {
    "amount": 300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "панам",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-12-03T05:34:13.000Z"
}, {
    "amount": 1550,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Конци",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-12-03T05:39:36.000Z"
}, {
    "amount": 90,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Стафиди",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-03T05:40:00.000Z"
}, {
    "amount": 140,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Кори и моркови",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-03T05:40:17.000Z"
}, {
    "amount": 280,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мляко, хляб",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-04T05:38:15.000Z"
}, {
    "amount": 69,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ориз",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-04T05:38:36.000Z"
}, {
    "amount": 200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Рамус - даване на кръв",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-04T05:39:04.000Z"
}, {
    "amount": 1350,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Шаран и лепенки",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-04T05:40:48.000Z"
}, {
    "amount": 1145,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Кокошка",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-04T05:41:05.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-05T15:16:09.000Z"
}, {
    "amount": 350,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Картофи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-05T05:36:58.000Z"
}, {
    "amount": 394,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Тиква",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-05T05:37:37.000Z"
}, {
    "amount": 370,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода и курабии",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-05T05:37:55.000Z"
}, {
    "amount": 6150,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-06T10:02:44.000Z"
}, {
    "amount": 11742,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-06T10:03:13.000Z"
}, {
    "amount": 109,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Кори",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-06T05:36:18.000Z"
}, {
    "amount": 2400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "DHL услуга за плащане на Митницата",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-07T07:39:29.000Z"
}, {
    "amount": 3362,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "20% ДДС  #Митница",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-07T07:40:36.000Z"
}, {
    "amount": 135,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Киви",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-07T05:34:31.000Z"
}, {
    "amount": 280,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Картофи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-07T05:34:56.000Z"
}, {
    "amount": 5634,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета за Мом",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-07T05:35:18.000Z"
}, {
    "amount": 200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "панер",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-12-07T05:35:51.000Z"
}, {
    "amount": 100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мляко Верия",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-07T05:36:38.000Z"
}, {
    "amount": 11457,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-08T13:43:47.000Z"
}, {
    "amount": 20914,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Позитивно приравняване",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-12-09T06:23:19.000Z"
}, {
    "amount": 1761,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-10T17:32:28.000Z"
}, {
    "amount": 574,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-10T17:33:15.000Z"
}, {
    "amount": 290,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Потребителска такса",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-10T17:34:45.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 10 пътувания",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-10T17:35:09.000Z"
}, {
    "amount": 680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-10T07:54:33.000Z"
}, {
    "amount": 3780,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лакрос топки за масаж",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-12-11T17:31:59.000Z"
}, {
    "amount": 551,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-11T17:32:55.000Z"
}, {
    "amount": 25,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Принтиране на резултати",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-11T17:33:51.000Z"
}, {
    "amount": 290,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "потребителска такса",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-11T17:34:24.000Z"
}, {
    "amount": 3000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Изследвания",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-11T17:35:35.000Z"
}, {
    "amount": 1780,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София - Червен бряг",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-12-12T07:55:19.000Z"
}, {
    "amount": 1867,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Еми 6",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-12T09:55:40.000Z"
}, {
    "amount": 157,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-12T09:56:12.000Z"
}, {
    "amount": 989,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Иван Войков-Виктория",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-12T09:56:48.000Z"
}, {
    "amount": 2145,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-12T09:32:15.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фитнес в Червен бряг",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-12-12T09:32:52.000Z"
}, {
    "amount": 2108,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Скица за акт 16",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-12T09:35:15.000Z"
}, {
    "amount": 300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Брашно",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-13T09:30:57.000Z"
}, {
    "amount": 3558,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Дицинон",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-14T09:29:48.000Z"
}, {
    "amount": 672,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-14T09:30:09.000Z"
}, {
    "amount": 3707,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-14T13:09:31.000Z"
}, {
    "amount": 420,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-14T13:09:46.000Z"
}, {
    "amount": 18250,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обувки Nano 8",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2018-12-15T10:39:51.000Z"
}, {
    "amount": 170,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-15T10:46:23.000Z"
}, {
    "amount": 3295,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "пържоли",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-15T13:08:56.000Z"
}, {
    "amount": 120,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-16T15:24:16.000Z"
}, {
    "amount": 475,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-16T15:24:30.000Z"
}, {
    "amount": 200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:42:37.000Z"
}, {
    "amount": 638,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:43:00.000Z"
}, {
    "amount": 916,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:43:20.000Z"
}, {
    "amount": 648,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:43:37.000Z"
}, {
    "amount": 105,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:43:53.000Z"
}, {
    "amount": 270,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:44:08.000Z"
}, {
    "amount": 740,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-17T08:44:20.000Z"
}, {
    "amount": 500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "На Чебето пазара",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-18T07:54:40.000Z"
}, {
    "amount": 186,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пресни Картофи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-18T08:41:49.000Z"
}, {
    "amount": 2191,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-18T13:16:56.000Z"
}, {
    "amount": 340,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-18T14:28:07.000Z"
}, {
    "amount": 9446,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Изравнителен данък",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-20T07:03:29.000Z"
}, {
    "amount": 29690,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "такса нот.акт",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-20T04:31:30.000Z"
}, {
    "amount": 1380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "количка за пазар",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2018-12-20T04:33:00.000Z"
}, {
    "amount": 1665,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "моят магазин",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-20T04:37:51.000Z"
}, {
    "amount": 2800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "мъжко портмоне",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2018-12-21T04:33:43.000Z"
}, {
    "amount": 430,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "клещи за рязане на тел",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2018-12-21T04:35:27.000Z"
}, {
    "amount": 1150,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "плод и зеленчук",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-21T04:40:53.000Z"
}, {
    "amount": 2110,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Тамара и Иван",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-21T04:43:32.000Z"
}, {
    "amount": 1385,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "храна от пчелата",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-21T04:45:49.000Z"
}, {
    "amount": 6650,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "кауфлант",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-22T04:23:28.000Z"
}, {
    "amount": 1860,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг <=> Плевен билети ",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2018-12-22T04:26:34.000Z"
}, {
    "amount": 8419,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "БИЛЛА",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-22T04:27:14.000Z"
}, {
    "amount": 810,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "ЛИДЛ",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-22T04:27:42.000Z"
}, {
    "amount": 1832,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Карзил Макс",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2018-12-22T04:28:59.000Z"
}, {
    "amount": 5568,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "вода плодове хляб",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-26T09:33:26.000Z"
}, {
    "amount": 3578,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефон и интернет София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-26T09:35:40.000Z"
}, {
    "amount": 610,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "пържоли",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-27T03:51:58.000Z"
}, {
    "amount": 2678,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "виваком интернет и мобилен интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2018-12-27T09:29:15.000Z"
}, {
    "amount": 445,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "плодове",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-28T03:52:04.000Z"
}, {
    "amount": 2964,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "продукти за нова година",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-29T03:52:22.000Z"
}, {
    "amount": 3222,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "пържоли",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-30T03:52:28.000Z"
}, {
    "amount": 1508,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "зеленчуци",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2018-12-31T03:52:33.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем за Януари",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-01-01T16:02:33.000Z"
}, {
    "amount": 1533,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "пържоли",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-04T15:42:17.000Z"
}, {
    "amount": 370000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Януари месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-01-05T03:49:03.000Z"
}, {
    "amount": 21000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-01-07T11:21:22.000Z"
}, {
    "amount": 3785,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "храна от пчелата",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-13T15:44:31.000Z"
}, {
    "amount": 4177,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-20T03:47:43.000Z"
}, {
    "amount": 8074,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-20T03:47:58.000Z"
}, {
    "amount": 6658,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Тел, Интернет и Газ такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-01-21T03:46:59.000Z"
}, {
    "amount": 2800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Тъй като заплатата е повече",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-01-23T04:13:37.000Z"
}, {
    "amount": 1440,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода плодове хляб",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-01-23T14:44:09.000Z"
}, {
    "amount": 3692,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-23T06:45:04.000Z"
}, {
    "amount": 19500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Myprotein Impact Whey Isolate, BCAA and Omega 3 pills от readyforlife ",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2019-01-24T07:44:13.000Z"
}, {
    "amount": 6470,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lube",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-01-24T17:22:28.000Z"
}, {
    "amount": 1116,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пица от Dominos",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-01-26T14:51:14.000Z"
}, {
    "amount": 1680,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сметки",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-01-27T07:18:57.000Z"
}, {
    "amount": 3795,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Нов Чадър",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-01-28T09:34:43.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Февруари",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-02-01T08:49:30.000Z"
}, {
    "amount": 4837,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-02T10:47:28.000Z"
}, {
    "amount": 8425,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-06T08:16:04.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-02-08T06:40:36.000Z"
}, {
    "amount": 4079,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-09T03:56:29.000Z"
}, {
    "amount": 5842,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-09T06:35:50.000Z"
}, {
    "amount": 21820,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-02-11T03:54:28.000Z"
}, {
    "amount": 799,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "мтел - мом",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-02-11T03:55:43.000Z"
}, {
    "amount": 2700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-11T03:56:13.000Z"
}, {
    "amount": 598,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-11T03:57:34.000Z"
}, {
    "amount": 3961,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-16T11:37:05.000Z"
}, {
    "amount": 1668,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-16T11:37:35.000Z"
}, {
    "amount": 1512,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-17T11:35:48.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 10 пътувания",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-02-17T11:36:23.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фингър тайп 2.5см х 4",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2019-02-17T11:38:19.000Z"
}, {
    "amount": 310,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-19T06:32:45.000Z"
}, {
    "amount": 1480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-02-22T13:25:18.000Z"
}, {
    "amount": 3745,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток и вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-02-22T13:33:25.000Z"
}, {
    "amount": 4521,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-24T03:47:52.000Z"
}, {
    "amount": 1854,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-02-24T03:48:20.000Z"
}, {
    "amount": 1483,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хапчета от Марешки #flu",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-02-24T03:49:19.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Март",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-03-01T15:20:16.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-03-01T04:04:01.000Z"
}, {
    "amount": 6570,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-01T15:16:42.000Z"
}, {
    "amount": 5346,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефон и интернет София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-03-01T15:18:14.000Z"
}, {
    "amount": 2373,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пробиотик и други неща",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-03-03T10:56:18.000Z"
}, {
    "amount": 279,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-03T10:56:39.000Z"
}, {
    "amount": 3374,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-04T07:07:58.000Z"
}, {
    "amount": 1348,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-05T07:12:58.000Z"
}, {
    "amount": 127100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Decathlon - Compex SP 2.0 with extra pads",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2019-03-06T01:36:41.000Z"
}, {
    "amount": 1810,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сумамед, памук и спирт",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-03-07T02:51:40.000Z"
}, {
    "amount": 2630,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-07T02:52:23.000Z"
}, {
    "amount": 2357,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-07T02:52:54.000Z"
}, {
    "amount": 3542,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-09T03:32:24.000Z"
}, {
    "amount": 2373,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Симфония Ройтери, Нурофен",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-03-10T01:35:10.000Z"
}, {
    "amount": 279,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-10T01:36:06.000Z"
}, {
    "amount": 15161,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-03-11T15:26:58.000Z"
}, {
    "amount": 14030,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Приравняване",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-03-16T15:29:44.000Z"
}, {
    "amount": 29850,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Плащане на хостинг услуги за 2 години",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-03-17T02:20:12.000Z"
}, {
    "amount": 10000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mr.Pizza",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-17T14:49:07.000Z"
}, {
    "amount": 8098,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-17T14:50:29.000Z"
}, {
    "amount": 1480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4 големи туби вода",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-03-18T13:05:40.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Март месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-03-21T16:24:11.000Z"
}, {
    "amount": 2711,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-21T12:11:33.000Z"
}, {
    "amount": 4158,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-24T15:50:31.000Z"
}, {
    "amount": 5398,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-03-30T11:45:57.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Април",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-04-01T02:21:45.000Z"
}, {
    "amount": 1714,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-03T02:20:58.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-04-05T06:50:51.000Z"
}, {
    "amount": 5933,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-06T11:51:17.000Z"
}, {
    "amount": 5859,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-12T12:02:17.000Z"
}, {
    "amount": 1400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "таксита",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-04-12T12:02:39.000Z"
}, {
    "amount": 1240,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминс пица",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-12T15:37:44.000Z"
}, {
    "amount": 9240,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-14T00:26:16.000Z"
}, {
    "amount": 1000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сирвър сити байсен",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2019-04-18T11:52:30.000Z"
}, {
    "amount": 4766,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-04-20T00:27:31.000Z"
}, {
    "amount": 6383,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сметки за тел и интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-04-20T00:29:24.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Май",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-05-01T02:21:49.000Z"
}, {
    "amount": 218965,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Вкарани чрез EasyPay",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-01T16:15:36.000Z"
}, {
    "amount": 77500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Нова пералня",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-02T07:39:37.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-05T06:51:07.000Z"
}, {
    "amount": 195800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обръщане в евро (1.9612768)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-07T04:29:41.000Z"
}, {
    "amount": 100000,
    "currency": "EUR",
    "walletID": "6273af174d6d4f98f09d3493",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Exchange rate (1.9612768)",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-13T03:51:32.000Z",
    "otherCurrency": {"amount": 195000, "currency": "BGN", "rate": 1.961276}
}, {
    "amount": 1049,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-13T03:25:52.000Z"
}, {
    "amount": 628600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-05-14T07:41:55.000Z"
}, {
    "amount": 4091,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-14T04:12:57.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "10 билетчета",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-05-15T04:12:06.000Z"
}, {
    "amount": 5791,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-15T04:15:09.000Z"
}, {
    "amount": 54900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "iPhone SE",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-15T04:54:14.000Z"
}, {
    "amount": 5462,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Bar Happy",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2019-05-18T23:45:52.000Z"
}, {
    "amount": 1283,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Аптека",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-05-18T23:46:37.000Z"
}, {
    "amount": 19996,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Reserved",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-18T23:47:02.000Z"
}, {
    "amount": 9990,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zara",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-18T23:47:27.000Z"
}, {
    "amount": 2294,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-18T23:47:50.000Z"
}, {
    "amount": 120,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода от фитнеса",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-20T03:41:15.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ед. посещение за фитнеса",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2019-05-21T01:40:16.000Z"
}, {
    "amount": 3336,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-24T03:57:39.000Z"
}, {
    "amount": 461,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-24T03:57:59.000Z"
}, {
    "amount": 2898,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-24T04:13:20.000Z"
}, {
    "amount": 3939,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-25T05:56:35.000Z"
}, {
    "amount": 50000,
    "currency": "EUR",
    "walletID": "6273af174d6d4f98f09d3493",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Exchange rate (1.9612769)",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-25T10:48:40.000Z",
    "otherCurrency": {"amount": 97500, "currency": "BGN", "rate": 1.961276}
}, {
    "amount": 97950,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обръщане в евро (1.9612769)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-25T03:56:28.000Z"
}, {
    "amount": 6997,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Осигоровки за 1-2-3 месец 2019",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-05-25T11:02:41.000Z"
}, {
    "amount": 3629,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-25T11:03:15.000Z"
}, {
    "amount": 150000,
    "currency": "EUR",
    "walletID": "6273af174d6d4f98f09d3493",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Exchange rate (1.9612769)",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-26T03:55:23.000Z",
    "otherCurrency": {"amount": 292500, "currency": "BGN", "rate": 1.961276}
}, {
    "amount": 293850,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обръщане в евро (1.9612769)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-26T03:56:14.000Z"
}, {
    "amount": 551,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-26T06:24:58.000Z"
}, {
    "amount": 884,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-26T04:25:21.000Z"
}, {
    "amount": 195900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обръщане в евро (1.9612769)",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-05-26T04:25:25.000Z"
}, {
    "amount": 100000,
    "currency": "EUR",
    "walletID": "6273af174d6d4f98f09d3493",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Exchange rate (1.9612769)",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-05-26T15:31:26.000Z",
    "otherCurrency": {"amount": 195000, "currency": "BGN", "rate": 1.961276}
}, {
    "amount": 10000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "болнични мама",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-05-27T09:37:17.000Z"
}, {
    "amount": 160300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "не знам какво става...",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-05-28T12:58:28.000Z"
}, {
    "amount": 1300,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминс пица",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-05-31T13:06:31.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Юни",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-06-01T04:36:17.000Z"
}, {
    "amount": 5521,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-01T13:07:04.000Z"
}, {
    "amount": 5954,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-05T11:22:37.000Z"
}, {
    "amount": 824,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефон",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-06T04:05:34.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-08T05:20:08.000Z"
}, {
    "amount": 7963,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-08T14:34:21.000Z"
}, {
    "amount": 917,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-08T11:54:59.000Z"
}, {
    "amount": 828,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Мама м-тел телефон",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-08T11:55:31.000Z"
}, {
    "amount": 2591,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-08T11:55:47.000Z"
}, {
    "amount": 1480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода от гаража",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-06-13T12:18:59.000Z"
}, {
    "amount": 3000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Първа среща с Александра. Искаше да даде 20лв, но взех само 10",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2019-06-14T05:48:25.000Z"
}, {
    "amount": 1824,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-15T05:48:46.000Z"
}, {
    "amount": 6535,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-15T05:49:04.000Z"
}, {
    "amount": 27500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Sexo.bg",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2019-06-18T09:27:51.000Z"
}, {
    "amount": 4539,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-20T02:36:53.000Z"
}, {
    "amount": 3365,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток, вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-20T02:37:18.000Z"
}, {
    "amount": 8488,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-23T04:35:23.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода от гаража",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-06-25T15:02:26.000Z"
}, {
    "amount": 5514,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "а1, виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-06-25T02:33:08.000Z"
}, {
    "amount": 5551,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-25T04:34:31.000Z"
}, {
    "amount": 12119,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-06-29T04:35:46.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Юли",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-07-01T12:25:22.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-07-01T04:50:46.000Z"
}, {
    "amount": 3876,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-01T14:35:17.000Z"
}, {
    "amount": 6737,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-02T14:34:06.000Z"
}, {
    "amount": 5216,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-06T09:19:08.000Z"
}, {
    "amount": 1283,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Овергаз",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-07-06T09:23:11.000Z"
}, {
    "amount": 4974,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-09T09:18:39.000Z"
}, {
    "amount": 1480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода от гаража",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-10T06:25:02.000Z"
}, {
    "amount": 4442,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-15T07:04:26.000Z"
}, {
    "amount": 1894,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-19T02:25:06.000Z"
}, {
    "amount": 2628,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-20T02:25:29.000Z"
}, {
    "amount": 10000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Проверка на очи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-21T02:23:21.000Z"
}, {
    "amount": 2500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Проверка на очи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-21T02:23:51.000Z"
}, {
    "amount": 6285,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Sasa ресторант",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2019-07-21T01:37:38.000Z"
}, {
    "amount": 519,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-22T02:21:56.000Z"
}, {
    "amount": 1137,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-22T02:22:35.000Z"
}, {
    "amount": 351,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-22T02:22:54.000Z"
}, {
    "amount": 150,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бабала",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-22T02:24:16.000Z"
}, {
    "amount": 13503,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Не сме бройли стотинките",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-07-23T02:41:24.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Август",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-07-23T11:52:28.000Z"
}, {
    "amount": 40000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Комисионна на агенцията",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-07-23T11:52:59.000Z"
}, {
    "amount": 1836,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-24T04:21:06.000Z"
}, {
    "amount": 369,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-24T04:21:29.000Z"
}, {
    "amount": 533,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-25T02:26:47.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро - 10 пътувания",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-07-25T02:27:20.000Z"
}, {
    "amount": 190,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бабала",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-25T02:27:45.000Z"
}, {
    "amount": 1570,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Магазин за един лев",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-25T02:29:00.000Z"
}, {
    "amount": 3935,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-26T06:43:26.000Z"
}, {
    "amount": 120,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Хаус Маркет",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-27T06:42:50.000Z"
}, {
    "amount": 9375,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Икеа",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-27T06:45:57.000Z"
}, {
    "amount": 0,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "23.80",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-27T06:56:51.000Z"
}, {
    "amount": 410,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-07-27T07:00:11.000Z"
}, {
    "amount": 5114,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-28T07:57:09.000Z"
}, {
    "amount": 443,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бакалия 2014",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-28T06:42:22.000Z"
}, {
    "amount": 407,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Марешки",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-07-28T06:48:09.000Z"
}, {
    "amount": 1400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Domino's",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-28T07:56:46.000Z"
}, {
    "amount": 7105,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-29T06:40:30.000Z"
}, {
    "amount": 4655,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-07-29T11:51:57.000Z"
}, {
    "amount": 1736,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-02T04:21:53.000Z"
}, {
    "amount": 1064,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-02T13:06:23.000Z"
}, {
    "amount": 576,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-03T10:26:41.000Z"
}, {
    "amount": 1238,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-03T10:27:14.000Z"
}, {
    "amount": 820,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода от маджите",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-03T10:27:56.000Z"
}, {
    "amount": 2765,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Домино",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-03T10:28:34.000Z"
}, {
    "amount": 208,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "т-маркет",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-04T10:25:58.000Z"
}, {
    "amount": 2009,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Т-маркет",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-05T10:25:34.000Z"
}, {
    "amount": 544,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-05T05:52:39.000Z"
}, {
    "amount": 955,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-06T05:53:03.000Z"
}, {
    "amount": 1540,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "До пловдив и обратно",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-08-06T05:54:32.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Нотариус",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-08-06T05:55:47.000Z"
}, {
    "amount": 311,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-07T05:51:27.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-08-08T05:02:13.000Z"
}, {
    "amount": 4301,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "USB hub and SD card reader",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-08-08T05:52:11.000Z"
}, {
    "amount": 508,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-08T05:53:25.000Z"
}, {
    "amount": 364,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-08T12:55:59.000Z"
}, {
    "amount": 2876,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-09T03:24:46.000Z"
}, {
    "amount": 247,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Цба",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-09T00:54:48.000Z"
}, {
    "amount": 1180,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-09T00:55:19.000Z"
}, {
    "amount": 2690,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Domino's",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-11T00:53:33.000Z"
}, {
    "amount": 1136,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-11T00:54:03.000Z"
}, {
    "amount": 4781,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-14T02:06:03.000Z"
}, {
    "amount": 2500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Две пици",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-17T06:58:53.000Z"
}, {
    "amount": 4107,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-20T10:32:57.000Z"
}, {
    "amount": 6274,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1, Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-08-20T10:38:28.000Z"
}, {
    "amount": 4600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вход, Сметки",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-08-21T14:06:07.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Септември*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-08-23T12:58:59.000Z"
}, {
    "amount": 396,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Т-маркет (диня, вълшебна просто!!!)",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-24T08:28:18.000Z"
}, {
    "amount": 1174,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чейз Бургер и Сердо или Гочо",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-24T08:29:32.000Z"
}, {
    "amount": 2167,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фантастико, Суши",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-24T04:00:48.000Z"
}, {
    "amount": 2010,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-24T04:03:48.000Z"
}, {
    "amount": 879,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-24T04:04:33.000Z"
}, {
    "amount": 1642,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-25T04:00:03.000Z"
}, {
    "amount": 396,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-25T04:01:17.000Z"
}, {
    "amount": 356,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-25T04:03:26.000Z"
}, {
    "amount": 465,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-25T04:04:18.000Z"
}, {
    "amount": 5743,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-27T01:36:46.000Z"
}, {
    "amount": 1415,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-28T01:33:59.000Z"
}, {
    "amount": 467,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-28T01:36:02.000Z"
}, {
    "amount": 1755,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Марешки - капки",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-08-28T01:37:35.000Z"
}, {
    "amount": 481,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-29T04:33:39.000Z"
}, {
    "amount": 580,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-08-30T04:56:06.000Z"
}, {
    "amount": 24000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Смяна на батерия и почистване на лаптопа",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-08-30T04:56:53.000Z"
}, {
    "amount": 2918,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-03T07:15:07.000Z"
}, {
    "amount": 4365,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-06T03:07:56.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-09-08T05:02:33.000Z"
}, {
    "amount": 2094,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-08T06:15:46.000Z"
}, {
    "amount": 1849,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-12T05:25:45.000Z"
}, {
    "amount": 428,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-12T15:52:46.000Z"
}, {
    "amount": 2067,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-14T07:12:38.000Z"
}, {
    "amount": 236,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-16T07:13:46.000Z"
}, {
    "amount": 6274,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1/Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-09-16T07:15:58.000Z"
}, {
    "amount": 2515,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток - София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-09-16T07:16:28.000Z"
}, {
    "amount": 1063,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-18T14:38:04.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Октомври*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-09-20T06:16:01.000Z"
}, {
    "amount": 3000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Такса за вход",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-09-20T07:13:29.000Z"
}, {
    "amount": 91900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "хмм",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-09-21T06:17:32.000Z"
}, {
    "amount": 90,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "кафе",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2019-09-22T05:08:33.000Z"
}, {
    "amount": 240,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-22T13:20:57.000Z"
}, {
    "amount": 2380,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "PizzaLab",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-22T13:21:19.000Z"
}, {
    "amount": 1400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Domino Pizza",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-22T13:21:38.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-22T13:21:52.000Z"
}, {
    "amount": 1454,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-24T11:12:25.000Z"
}, {
    "amount": 1722,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла - чипс",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-09-26T07:41:43.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Ноември*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-10-01T02:54:28.000Z"
}, {
    "amount": 905,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-03T02:53:26.000Z"
}, {
    "amount": 798,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла - питиета",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-05T07:44:53.000Z"
}, {
    "amount": 3500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Domino's - 3 джъмбо пици, като едната е на 4 лв цена",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-06T08:47:05.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-10-08T05:02:57.000Z"
}, {
    "amount": 870,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Заболекар",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-10-14T07:36:57.000Z"
}, {
    "amount": 1050,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Спагети номер 1",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-16T16:07:46.000Z"
}, {
    "amount": 800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Еклери",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-16T16:08:07.000Z"
}, {
    "amount": 690,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Заболекар",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-10-16T07:36:42.000Z"
}, {
    "amount": 2230,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода за уста",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-10-17T16:07:22.000Z"
}, {
    "amount": 8820,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-10-18T12:54:42.000Z"
}, {
    "amount": 6481,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-19T04:25:20.000Z"
}, {
    "amount": 500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Влак - Чебето->София",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2019-10-19T10:36:49.000Z"
}, {
    "amount": 1448,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-20T07:35:22.000Z"
}, {
    "amount": 3866,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пилешко филе - Чебето",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-20T07:35:41.000Z"
}, {
    "amount": 4291,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Gush Термос 650мл",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-10-22T05:24:35.000Z"
}, {
    "amount": 2428,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-23T07:42:09.000Z"
}, {
    "amount": 1391,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": " Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-24T07:47:05.000Z"
}, {
    "amount": 605,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-10-28T11:46:02.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Декември",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-11-01T07:48:51.000Z"
}, {
    "amount": 1572,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-02T08:16:21.000Z"
}, {
    "amount": 1850,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лакрос топка",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2019-11-02T08:16:42.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Dominos 3 pizzas",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-02T15:37:49.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-11-08T16:16:11.000Z"
}, {
    "amount": 3843,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-10T10:41:45.000Z"
}, {
    "amount": 1994,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-10T13:18:32.000Z"
}, {
    "amount": 3338,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "CBA",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-10T13:18:45.000Z"
}, {
    "amount": 4028,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-13T16:30:56.000Z"
}, {
    "amount": 3163,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-15T02:56:47.000Z"
}, {
    "amount": 326,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-19T09:07:41.000Z"
}, {
    "amount": 2072,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4C ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-11-19T09:08:35.000Z"
}, {
    "amount": 6274,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-11-19T09:09:12.000Z"
}, {
    "amount": 77900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "...",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-11-21T16:02:42.000Z"
}, {
    "amount": 44600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Коледни Подаръци",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2019-11-21T16:06:20.000Z"
}, {
    "amount": 775,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София - вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-11-25T10:05:59.000Z"
}, {
    "amount": 1464,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-11-25T10:06:14.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Януари*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2019-12-01T14:58:38.000Z"
}, {
    "amount": 16405,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Notino",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-12-03T03:09:50.000Z"
}, {
    "amount": 2611,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-12-03T15:51:32.000Z"
}, {
    "amount": 2164,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-12-09T15:51:46.000Z"
}, {
    "amount": 819,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-12-10T13:59:00.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември месец",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-12-11T15:02:05.000Z"
}, {
    "amount": 25900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "ужас...",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-12-12T06:30:47.000Z"
}, {
    "amount": 5674,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-12-14T15:13:43.000Z"
}, {
    "amount": 4862,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2019-12-17T11:46:46.000Z"
}, {
    "amount": 6274,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-12-19T09:11:46.000Z"
}, {
    "amount": 5048,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София 4c",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-12-19T09:12:08.000Z"
}, {
    "amount": 4760,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2019-12-19T09:12:41.000Z"
}, {
    "amount": 50000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Към башето",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2019-12-23T14:14:34.000Z"
}, {
    "amount": 50000,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "От башето",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-12-23T14:34:25.000Z"
}, {
    "amount": 55685,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Болнични",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-12-28T14:34:19.000Z"
}, {
    "amount": 1726,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Celeste",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2019-12-28T14:36:26.000Z"
}, {
    "amount": 32813,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "общо 30666",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2019-12-30T06:24:18.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Февруари*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-01-01T11:57:21.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Star Wars: Episode IX The Rise of Skywalker #4DX",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2020-01-02T13:26:13.000Z"
}, {
    "amount": 430,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cinema City Cafe",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2020-01-02T13:26:50.000Z"
}, {
    "amount": 889,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cinema City: PopCorn and Drinks",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2020-01-02T13:27:29.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Захранване",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-03T13:23:16.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Към УниКредит Сметката",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-03T14:15:42.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Януари месец*",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-08T14:10:18.000Z"
}, {
    "amount": 2183,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-01-09T02:09:42.000Z"
}, {
    "amount": 105800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "DYNAPHOS",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-09T02:16:22.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "10 билетчета за Метрото",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2020-01-13T02:10:46.000Z"
}, {
    "amount": 8000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Очна клиника Vision",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-01-13T02:11:25.000Z"
}, {
    "amount": 2798,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-13T02:12:00.000Z"
}, {
    "amount": 2600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-01-13T02:12:12.000Z"
}, {
    "amount": 155,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-01-14T05:52:51.000Z"
}, {
    "amount": 1421,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Капки от Марешки",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-01-14T05:53:26.000Z"
}, {
    "amount": 4072,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-01-15T05:52:34.000Z"
}, {
    "amount": 6316,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чебето сметки",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-17T08:46:57.000Z"
}, {
    "amount": 10236,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София 4C - ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-17T08:47:27.000Z"
}, {
    "amount": 50000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Заем на Дебелият",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-19T12:17:18.000Z"
}, {
    "amount": 38000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "интересно",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-19T12:24:02.000Z"
}, {
    "amount": 2500000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "на Емо",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2020-01-21T14:20:20.000Z"
}, {
    "amount": 487,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-01-22T11:56:28.000Z"
}, {
    "amount": 1606,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода - София 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-22T11:58:35.000Z"
}, {
    "amount": 50,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-23T06:45:16.000Z"
}, {
    "amount": 28000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zeiss Duravision Silver оптични лещи с антирефлексно покритие",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-01-24T05:10:33.000Z"
}, {
    "amount": 890,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София -> Чебето",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2020-01-24T05:01:02.000Z"
}, {
    "amount": 50000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Върнати от Дебелият",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-26T05:10:52.000Z"
}, {
    "amount": 6000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Добавка - Zeiss DV BlueProtect стъкла с антирефлекс и BlueBlocker филтър",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-01-27T05:11:25.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Периодична такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-01-27T06:44:45.000Z"
}, {
    "amount": 700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "крушка за Чебето",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-01-28T04:59:47.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Март*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-02-01T12:00:00.000Z"
}, {
    "amount": 3010,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-05T11:26:20.000Z"
}, {
    "amount": 69439,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": ".. #fun",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-02-07T11:25:13.000Z"
}, {
    "amount": 2139,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-07T11:26:40.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-07T12:11:04.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари*",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-08T12:02:22.000Z"
}, {
    "amount": 1499,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-08T12:10:51.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mr. Pizza",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2020-02-09T16:00:15.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "метро 10бр",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2020-02-11T12:46:00.000Z"
}, {
    "amount": 310,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-11T06:14:08.000Z"
}, {
    "amount": 1862,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-13T05:33:30.000Z"
}, {
    "amount": 2364,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-14T13:23:35.000Z"
}, {
    "amount": 4500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Америмед",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-02-14T09:42:52.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сушито.бг",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-16T09:43:08.000Z"
}, {
    "amount": 6702,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-17T11:32:04.000Z"
}, {
    "amount": 1992,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-02-18T14:39:20.000Z"
}, {
    "amount": 12304,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-19T10:03:55.000Z"
}, {
    "amount": 6477,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефони и Интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-19T10:05:32.000Z"
}, {
    "amount": 492,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-19T09:59:17.000Z"
}, {
    "amount": 2585,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Aseprite",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-02-20T14:27:20.000Z"
}, {
    "amount": 180,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Минерална вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-20T20:35:12.000Z"
}, {
    "amount": 880,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "minibar",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-23T10:20:25.000Z"
}, {
    "amount": 5500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Суши",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-23T11:05:40.000Z"
}, {
    "amount": 620,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-23T04:13:47.000Z"
}, {
    "amount": 673320,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-24T09:25:41.000Z"
}, {
    "amount": 1000000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "25 Фев 2020 14:51:45",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-25T12:53:00.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Периодична такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-02-26T06:44:32.000Z"
}, {
    "amount": 2531,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-02-27T09:58:52.000Z"
}, {
    "amount": 6000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "SaSa",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2020-02-29T04:35:06.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Април*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-03-01T12:00:19.000Z"
}, {
    "amount": 7213,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-01T04:35:26.000Z"
}, {
    "amount": 2800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Капки за очи х 2бр",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-03-02T15:18:27.000Z"
}, {
    "amount": 5639,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-02T15:18:49.000Z"
}, {
    "amount": 1385,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София - Вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-02T15:19:05.000Z"
}, {
    "amount": 27998,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Philips Hue Go - 2бр",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-03-04T07:36:32.000Z"
}, {
    "amount": 5742,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-05T09:31:14.000Z"
}, {
    "amount": 17900,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Връщане от DYNAPHOS заради неполучена Manfrotto Lumimuse светлина ",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-03-06T12:14:19.000Z"
}, {
    "amount": 7705,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-03-06T14:36:51.000Z"
}, {
    "amount": 4872,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-08T10:10:57.000Z"
}, {
    "amount": 7462,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "изтегляне всичко от ЦКБ сметката",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-03-09T09:26:17.000Z"
}, {
    "amount": 717,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-09T09:26:33.000Z"
}, {
    "amount": 100101,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "от Дебелия",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-03-09T02:27:03.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Март",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-11T16:58:04.000Z"
}, {
    "amount": 661,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-11T10:10:24.000Z"
}, {
    "amount": 4841,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-16T10:13:01.000Z"
}, {
    "amount": 947,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-17T09:07:21.000Z"
}, {
    "amount": 3570,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-17T09:08:23.000Z"
}, {
    "amount": 9406,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София - ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-17T09:08:44.000Z"
}, {
    "amount": 2921,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-17T09:08:58.000Z"
}, {
    "amount": 14012,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-25T10:28:47.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Периодична такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-03-26T16:59:44.000Z"
}, {
    "amount": 820,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла 4х5 литра вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-03-29T12:22:53.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем Май*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-04-01T10:02:17.000Z"
}, {
    "amount": 919,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Маска",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-04-02T06:54:18.000Z"
}, {
    "amount": 6512,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-03T13:28:49.000Z"
}, {
    "amount": 1385,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода - София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-04-03T13:29:16.000Z"
}, {
    "amount": 40,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-04-06T09:02:55.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април*",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-04-08T10:01:39.000Z"
}, {
    "amount": 4977,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-08T14:51:31.000Z"
}, {
    "amount": 415000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "ддс",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-04-09T14:49:09.000Z"
}, {
    "amount": 10947,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-10T06:53:16.000Z"
}, {
    "amount": 4703,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-04-15T02:52:30.000Z"
}, {
    "amount": 9182,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-15T09:42:00.000Z"
}, {
    "amount": 1208,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Термометри и Броколи",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-04-22T09:39:50.000Z"
}, {
    "amount": 4466,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-22T09:40:15.000Z"
}, {
    "amount": 5477,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток-Вода 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-04-22T10:11:57.000Z"
}, {
    "amount": 4500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Rode аксесоари",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-04-24T07:05:13.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Периодична такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-04-26T14:31:16.000Z"
}, {
    "amount": 2693,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-28T11:34:30.000Z"
}, {
    "amount": 9137,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-04-30T04:06:55.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни*",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-05-01T10:02:12.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-01T14:31:56.000Z"
}, {
    "amount": 9248,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-07T13:54:17.000Z"
}, {
    "amount": 4494,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-11T14:00:43.000Z"
}, {
    "amount": 4262,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "2бр капки за очи",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-05-12T12:20:18.000Z"
}, {
    "amount": 4707,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-14T14:06:50.000Z"
}, {
    "amount": 2152,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-18T12:36:18.000Z"
}, {
    "amount": 2070,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4C - ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-19T12:37:13.000Z"
}, {
    "amount": 799,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 - мом",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-19T12:37:45.000Z"
}, {
    "amount": 1500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-05-24T10:07:09.000Z"
}, {
    "amount": 4972,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-24T10:07:24.000Z"
}, {
    "amount": 1817,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидл",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-24T10:07:39.000Z"
}, {
    "amount": 1385,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4C - вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-25T07:31:22.000Z"
}, {
    "amount": 2597,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "A1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-25T07:32:05.000Z"
}, {
    "amount": 2878,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Vivacom",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-05-25T07:32:31.000Z"
}, {
    "amount": 460000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "50% авансово плащане за MacBook Pro 16",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-05-25T04:43:25.000Z"
}, {
    "amount": 459100,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Завършване плащането на MacBook Pro",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-05-26T04:45:36.000Z"
}, {
    "amount": 3607,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-05-30T07:36:33.000Z"
}, {
    "amount": 360000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-06-01T06:56:29.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-06-01T06:57:05.000Z"
}, {
    "amount": 64999,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Final Cut Pro x",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-06-02T05:12:01.000Z"
}, {
    "amount": 10999,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Compressor",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-06-02T05:12:18.000Z"
}, {
    "amount": 150,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-06-02T05:13:08.000Z"
}, {
    "amount": 6904,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-05T07:22:15.000Z"
}, {
    "amount": 3949,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-09T07:11:59.000Z"
}, {
    "amount": 7996,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-13T08:17:05.000Z"
}, {
    "amount": 2106,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-18T07:19:06.000Z"
}, {
    "amount": 6288,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-06-18T07:20:59.000Z"
}, {
    "amount": 2459,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток - 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-06-18T07:21:17.000Z"
}, {
    "amount": 2748,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лидр",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-19T14:18:13.000Z"
}, {
    "amount": 3301,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-24T06:50:47.000Z"
}, {
    "amount": 746,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-25T15:02:12.000Z"
}, {
    "amount": 2500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Торта Титаник",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-25T15:02:23.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Forno Cipollini пици",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-27T11:21:37.000Z"
}, {
    "amount": 299,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла сладолед",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-06-27T01:44:14.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-07-06T14:16:38.000Z"
}, {
    "amount": 5465,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-19T08:48:22.000Z"
}, {
    "amount": 2500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "доминос пици",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-19T12:42:16.000Z"
}, {
    "amount": 235,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-19T12:42:39.000Z"
}, {
    "amount": 0,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Бонус заради работене през празниците",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-07-20T03:10:10.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-07-20T06:22:37.000Z"
}, {
    "amount": 2202,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-22T07:00:45.000Z"
}, {
    "amount": 4690,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 & Vivacom",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-07-22T03:19:04.000Z"
}, {
    "amount": 2837,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-27T02:39:52.000Z"
}, {
    "amount": 3449,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-07-31T02:40:05.000Z"
}, {
    "amount": 2900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-02T08:30:24.000Z"
}, {
    "amount": 3118,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-06T07:07:20.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-08-07T06:23:33.000Z"
}, {
    "amount": 3000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос Пици",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-08T03:05:01.000Z"
}, {
    "amount": 1548,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-10T03:05:29.000Z"
}, {
    "amount": 4726,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-12T14:11:11.000Z"
}, {
    "amount": 17985,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Zarra",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-08-15T04:43:41.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "На Башето",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2020-08-16T06:20:37.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-08-20T06:22:28.000Z"
}, {
    "amount": 1000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чип за вратата",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-08-20T06:22:54.000Z"
}, {
    "amount": 5665,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-20T15:10:23.000Z"
}, {
    "amount": 417,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "подправки",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-21T06:45:58.000Z"
}, {
    "amount": 1900,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-22T15:15:40.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Суши",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-23T08:00:54.000Z"
}, {
    "amount": 1612,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-26T07:04:29.000Z"
}, {
    "amount": 2277,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла - батерии за микрофона",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-26T07:11:05.000Z"
}, {
    "amount": 2445,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-27T07:11:25.000Z"
}, {
    "amount": 79810,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Mega Acoustic панели",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-08-29T09:32:24.000Z"
}, {
    "amount": 967,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-08-29T07:41:32.000Z"
}, {
    "amount": 791,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-01T07:27:28.000Z"
}, {
    "amount": 2389,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-02T12:24:52.000Z"
}, {
    "amount": 1272,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-10T03:53:47.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-09-10T10:37:01.000Z"
}, {
    "amount": 4211,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-11T07:46:49.000Z"
}, {
    "amount": 2385,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Доминос от Място",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-13T10:23:59.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Храна",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-18T15:11:27.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-09-20T10:37:48.000Z"
}, {
    "amount": 7498,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-21T06:26:39.000Z"
}, {
    "amount": 97000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Rode NTG5",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-09-22T06:27:06.000Z"
}, {
    "amount": 7000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Boom stand",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-09-22T06:27:37.000Z"
}, {
    "amount": 2455,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София 4С ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-09-22T06:27:58.000Z"
}, {
    "amount": 54,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сладолед",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-23T06:26:04.000Z"
}, {
    "amount": 39800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "2 фонови системи",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-09-23T07:01:14.000Z"
}, {
    "amount": 3360,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-27T06:32:19.000Z"
}, {
    "amount": 10660,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лубриканти",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-09-29T07:00:24.000Z"
}, {
    "amount": 1573,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-09-30T06:59:42.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-10-01T10:37:21.000Z"
}, {
    "amount": 1584,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-01T10:58:19.000Z"
}, {
    "amount": 28465,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-10-01T10:09:01.000Z"
}, {
    "amount": 2931,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-02T08:20:37.000Z"
}, {
    "amount": 2571,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-03T07:21:40.000Z"
}, {
    "amount": 2444,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-06T07:13:12.000Z"
}, {
    "amount": 119800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Нови светлини",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-10-06T07:03:10.000Z"
}, {
    "amount": 2420,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток - София 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-10-09T06:27:37.000Z"
}, {
    "amount": 658,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-09T06:28:08.000Z"
}, {
    "amount": 1315,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-10T10:09:25.000Z"
}, {
    "amount": 4830,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-10T08:23:05.000Z"
}, {
    "amount": 13819,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Fx Plugin Refund",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-10-12T07:27:16.000Z"
}, {
    "amount": 1045,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": " Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-14T03:39:54.000Z"
}, {
    "amount": 33176,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cloud Lifter",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-10-19T12:32:04.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-10-20T10:38:37.000Z"
}, {
    "amount": 17059,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "не знам, защо обаче",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-10-27T11:40:44.000Z"
}, {
    "amount": 67100,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "преди добавяне 3956, 36",
    "category": {
        "type": "debit",
        "name": "Подаръци",
        "id": "6273a1b78d8262e2fd1fc8f5",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2020-10-27T11:55:42.000Z"
}, {
    "amount": 1865,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-10-28T08:52:45.000Z"
}, {
    "amount": 201100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2020-10-28T10:31:03.000Z"
}, {
    "amount": 5049,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-01T09:47:55.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-11-04T17:00:23.000Z"
}, {
    "amount": 2855,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-05T08:49:06.000Z"
}, {
    "amount": 1929,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-09T06:19:01.000Z"
}, {
    "amount": 3964,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-11T10:23:26.000Z"
}, {
    "amount": 1200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Метро 10бр",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2020-11-14T08:47:29.000Z"
}, {
    "amount": 1908,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-15T14:38:50.000Z"
}, {
    "amount": 1659,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-16T05:01:46.000Z"
}, {
    "amount": 2394,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София ток 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-11-16T05:02:19.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-11-20T09:47:34.000Z"
}, {
    "amount": 388,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Такси",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-11-20T04:26:53.000Z"
}, {
    "amount": 6112,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-20T14:39:04.000Z"
}, {
    "amount": 3333,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-25T09:00:08.000Z"
}, {
    "amount": 3323,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-11-27T09:45:42.000Z"
}, {
    "amount": 4262,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Капки за очи",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2020-11-27T07:49:18.000Z"
}, {
    "amount": 5269,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ел. Одеяло",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2020-12-01T07:58:09.000Z"
}, {
    "amount": 1550,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-01T08:58:14.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-12-02T16:13:55.000Z"
}, {
    "amount": 6631,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-04T09:03:56.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Таски",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-12-05T15:54:22.000Z"
}, {
    "amount": 2920,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-08T09:17:31.000Z"
}, {
    "amount": 6511,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-09T08:07:43.000Z"
}, {
    "amount": 6865,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток София 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2020-12-10T14:04:16.000Z"
}, {
    "amount": 6629,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-13T08:07:22.000Z"
}, {
    "amount": 2801,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-16T08:34:34.000Z"
}, {
    "amount": 558,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-17T09:18:44.000Z"
}, {
    "amount": 1706,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-19T06:03:08.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2020-12-20T09:47:48.000Z"
}, {
    "amount": 767,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2020-12-20T01:46:01.000Z"
}, {
    "amount": 855,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София-Червен бряг",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2020-12-20T09:22:54.000Z"
}, {
    "amount": 484,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Life",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-21T13:29:56.000Z"
}, {
    "amount": 411,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Лукчета",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2020-12-23T12:26:43.000Z"
}, {
    "amount": 5000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2020-12-23T08:43:30.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Януари",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-01-02T16:14:27.000Z"
}, {
    "amount": 83000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-01-02T16:14:45.000Z"
}, {
    "amount": 13000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Башето рожден ден",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2021-01-03T07:20:29.000Z"
}, {
    "amount": 20000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-09T07:20:02.000Z"
}, {
    "amount": 20000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Баба",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2021-01-09T14:27:29.000Z"
}, {
    "amount": 105653,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Крипто",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-01-13T05:27:22.000Z"
}, {
    "amount": 2097,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-17T09:32:37.000Z"
}, {
    "amount": 1272,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Пица с Алба",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-01-17T06:05:23.000Z"
}, {
    "amount": 905,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Червен бряг - София",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2021-01-17T06:06:31.000Z"
}, {
    "amount": 843,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-19T08:29:45.000Z"
}, {
    "amount": 4934,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4С ток София",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-01-19T08:30:19.000Z"
}, {
    "amount": 1254,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-01-19T08:33:41.000Z"
}, {
    "amount": 3072,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-01-19T08:34:02.000Z"
}, {
    "amount": 1408,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ток - чебето",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-01-19T08:34:48.000Z"
}, {
    "amount": 4800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Philips тостер",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-01-22T06:20:00.000Z"
}, {
    "amount": 5844,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-22T08:40:40.000Z"
}, {
    "amount": 219,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фантастико",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-01-23T08:56:33.000Z"
}, {
    "amount": 4161,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-26T08:56:14.000Z"
}, {
    "amount": 1356,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-01-28T09:05:04.000Z"
}, {
    "amount": 2720,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-01T09:06:11.000Z"
}, {
    "amount": 678,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода - София",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-02T04:36:25.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Февруари",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-04T11:41:42.000Z"
}, {
    "amount": 2323,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-05T05:09:51.000Z"
}, {
    "amount": 163176,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "eToro",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-02-05T04:44:08.000Z"
}, {
    "amount": 163176,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "eToro",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-02-08T02:35:32.000Z"
}, {
    "amount": 1155,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-08T09:15:19.000Z"
}, {
    "amount": 2395,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-10T09:15:00.000Z"
}, {
    "amount": 478091,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Etoro",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-02-11T14:35:07.000Z"
}, {
    "amount": 984000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-12T06:10:22.000Z"
}, {
    "amount": 519718,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-12T11:40:47.000Z"
}, {
    "amount": 2197,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-12T09:52:01.000Z"
}, {
    "amount": 1524000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Deposit",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-02-12T09:51:53.000Z"
}, {
    "amount": 1727,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода, сок и яйца",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-13T08:06:56.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Славянска Беседа",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2021-02-13T08:32:21.000Z"
}, {
    "amount": 2433,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-17T09:09:40.000Z"
}, {
    "amount": 1631,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-18T09:00:28.000Z"
}, {
    "amount": 30378,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Изпращане на Баба",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-18T14:32:26.000Z"
}, {
    "amount": 329,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла - вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-18T14:32:48.000Z"
}, {
    "amount": 2681,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-19T04:28:36.000Z"
}, {
    "amount": 4175,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-22T04:28:18.000Z"
}, {
    "amount": 4397,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4C ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:19:15.000Z"
}, {
    "amount": 1223,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4C вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:19:51.000Z"
}, {
    "amount": 2578,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чебето ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:20:44.000Z"
}, {
    "amount": 1099,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "моят мтел телефон",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:21:45.000Z"
}, {
    "amount": 1637,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:22:02.000Z"
}, {
    "amount": 2921,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-02-22T05:22:23.000Z"
}, {
    "amount": 5255,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-02-25T08:51:41.000Z"
}, {
    "amount": 13486,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Silabg",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-02-26T08:16:35.000Z"
}, {
    "amount": 1370,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София-Чебето",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2021-02-28T08:58:59.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Март",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-01T11:53:36.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "bills",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-01T11:57:11.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "rent",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-01T11:53:09.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-01T11:55:00.000Z"
}, {
    "amount": 329,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-04T08:57:47.000Z"
}, {
    "amount": 2489,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-04T08:58:03.000Z"
}, {
    "amount": 8874,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-07T12:20:40.000Z"
}, {
    "amount": 2957,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-09T09:07:19.000Z"
}, {
    "amount": 4237,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-12T09:29:59.000Z"
}, {
    "amount": 427,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Fantastico",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-03-13T13:10:49.000Z"
}, {
    "amount": 1042,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "T-Market",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-13T13:11:17.000Z"
}, {
    "amount": 249,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "DM store",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-03-13T13:11:43.000Z"
}, {
    "amount": 869,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-14T15:09:29.000Z"
}, {
    "amount": 8283,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-16T14:57:54.000Z"
}, {
    "amount": 3266,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-19T09:01:00.000Z"
}, {
    "amount": 5195,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София - ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-19T09:02:22.000Z"
}, {
    "amount": 1299,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чебето - ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-19T09:03:00.000Z"
}, {
    "amount": 6775,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Телефони",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-19T09:04:40.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-03-20T11:54:30.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Платен наем",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-03-20T12:06:48.000Z"
}, {
    "amount": 3571,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-21T10:55:16.000Z"
}, {
    "amount": 4937,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-03-26T08:58:11.000Z"
}, {
    "amount": 60000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "На башето",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2021-04-01T01:40:40.000Z"
}, {
    "amount": 45764,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Unemployment",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-01T04:30:19.000Z"
}, {
    "amount": 3356,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-02T07:29:44.000Z"
}, {
    "amount": 23075,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "SuperHosting",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-02T07:30:05.000Z"
}, {
    "amount": 2120,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-05T06:36:05.000Z"
}, {
    "amount": 2830,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-08T06:35:24.000Z"
}, {
    "amount": 2955,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-12T07:47:30.000Z"
}, {
    "amount": 2730,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-14T06:58:17.000Z"
}, {
    "amount": 4343,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-16T06:58:42.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Април",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-16T14:36:19.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-04-16T14:36:45.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-16T14:37:05.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "rent",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-16T14:37:37.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "bills",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-16T14:37:47.000Z"
}, {
    "amount": 1980,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-16T14:38:37.000Z"
}, {
    "amount": 1200000,
    "currency": "USD",
    "walletID": "6273af17fc9ee46236763ddb",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "7750 usd",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-16T21:00:00.000Z",
    "otherCurrency": {"amount": 2220000, "currency": "BGN", "rate": 1.826938}
}, {
    "amount": 2779,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София ток - 4С",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-19T08:21:59.000Z"
}, {
    "amount": 702,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чебето Ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-19T08:22:56.000Z"
}, {
    "amount": 2798,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-19T08:23:47.000Z"
}, {
    "amount": 2950,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-04-19T08:24:10.000Z"
}, {
    "amount": 1448,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-19T08:26:03.000Z"
}, {
    "amount": 6190,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-24T05:34:18.000Z"
}, {
    "amount": 8000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Sushi - Tokyo Set",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-26T11:30:39.000Z"
}, {
    "amount": 2347,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-27T12:51:16.000Z"
}, {
    "amount": 450000,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Прехвърляне на башето",
    "category": {
        "type": "credit",
        "name": "Подаръци",
        "id": "6273a1b71c6a03fdae63e5cc",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gift.svg`
    },
    "createdAt": "2021-04-28T04:30:34.000Z"
}, {
    "amount": 450000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "От башето",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-28T04:30:50.000Z"
}, {
    "amount": 1580,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Decathlon",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-28T09:52:43.000Z"
}, {
    "amount": 1760,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Taxis",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2021-04-28T09:53:13.000Z"
}, {
    "amount": 200,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ice cake",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-28T09:53:28.000Z"
}, {
    "amount": 540,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Ikea",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-28T09:53:55.000Z"
}, {
    "amount": 450000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "eToro",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-28T10:08:00.000Z"
}, {
    "amount": 450000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "На башето",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-04-28T10:38:09.000Z"
}, {
    "amount": 450000,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "cash",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-04-28T10:38:27.000Z"
}, {
    "amount": 4384,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-28T12:59:04.000Z"
}, {
    "amount": 3265,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-29T13:09:19.000Z"
}, {
    "amount": 1426,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-04-30T06:22:07.000Z"
}, {
    "amount": 658,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-02T09:43:00.000Z"
}, {
    "amount": 3808,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-03T11:23:44.000Z"
}, {
    "amount": 1600,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Bubble House Waffles",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-05-03T11:24:25.000Z"
}, {
    "amount": 6006,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-05T07:29:36.000Z"
}, {
    "amount": 1796,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-05T04:55:22.000Z"
}, {
    "amount": 1259,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "DM",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-09T08:24:04.000Z"
}, {
    "amount": 7579,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-09T08:24:33.000Z"
}, {
    "amount": 3066,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-11T13:30:35.000Z"
}, {
    "amount": 3440,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Rois - насипни ядки",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-12T07:34:58.000Z"
}, {
    "amount": 7090,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-13T13:05:59.000Z"
}, {
    "amount": 4491,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "BIlla",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-17T13:59:03.000Z"
}, {
    "amount": 10309,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Общо сметки",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-05-19T09:34:18.000Z"
}, {
    "amount": 498,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-19T09:34:51.000Z"
}, {
    "amount": 3246,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-20T02:31:31.000Z"
}, {
    "amount": 714,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-20T02:32:07.000Z"
}, {
    "amount": 5200,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "MacDonald",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-21T14:59:41.000Z"
}, {
    "amount": 3120,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-22T10:08:00.000Z"
}, {
    "amount": 4200,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-22T11:27:46.000Z"
}, {
    "amount": 2508,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-22T15:20:09.000Z"
}, {
    "amount": 792,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-23T05:36:38.000Z"
}, {
    "amount": 4954,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-26T05:29:54.000Z"
}, {
    "amount": 422000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Nano X",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-05-28T03:10:50.000Z"
}, {
    "amount": 558000,
    "currency": "USD",
    "walletID": "6273af17bc5e3cce092af15d",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "5180 usd",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-05-27T21:00:00.000Z",
    "otherCurrency": {"amount": 1032300, "currency": "BGN", "rate": 1.826938}
}, {
    "amount": 6890,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-05-29T14:33:50.000Z"
}, {
    "amount": 180000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-05-29T21:00:00.000Z"
}, {
    "amount": 127000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "rend + bills",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-06-01T00:26:30.000Z"
}, {
    "amount": 5078,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-01T00:24:17.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За май",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-06-01T00:25:04.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-06-01T00:27:38.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-06-01T00:27:27.000Z"
}, {
    "amount": 22160,
    "currency": "BGN",
    "walletID": "6273af17db9b0ff00d1b3051",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-06-02T12:01:55.000Z"
}, {
    "amount": 718,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-03T13:37:34.000Z"
}, {
    "amount": 2395,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-04T04:29:22.000Z"
}, {
    "amount": 9400,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "KFC",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-06-04T06:30:27.000Z"
}, {
    "amount": 6570,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Rois",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-04T06:31:45.000Z"
}, {
    "amount": 6219,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-06T06:29:42.000Z"
}, {
    "amount": 5375,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-08T02:14:43.000Z"
}, {
    "amount": 4300,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Капки за очи",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2021-06-08T02:15:02.000Z"
}, {
    "amount": 6608,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-09T09:03:41.000Z"
}, {
    "amount": 5397,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "H&M",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-10T10:04:13.000Z"
}, {
    "amount": 3710,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-12T10:03:27.000Z"
}, {
    "amount": 5814,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-17T13:40:28.000Z"
}, {
    "amount": 977,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-18T12:34:14.000Z"
}, {
    "amount": 10400,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-06-18T12:34:42.000Z"
}, {
    "amount": 878,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-20T10:53:16.000Z"
}, {
    "amount": 11820,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Decathlon",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-06-20T10:53:48.000Z"
}, {
    "amount": 5884,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-23T12:46:29.000Z"
}, {
    "amount": 8000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Sushi",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-25T08:31:55.000Z"
}, {
    "amount": 1317,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-25T09:28:54.000Z"
}, {
    "amount": 5451,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-26T06:45:27.000Z"
}, {
    "amount": 1697,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-29T04:06:36.000Z"
}, {
    "amount": 8242,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-06-30T04:06:54.000Z"
}, {
    "amount": 3035,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-07-03T04:08:40.000Z"
}, {
    "amount": 7747,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-07-04T09:37:01.000Z"
}, {
    "amount": 3990,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Deichmann shoes / 51011775*0000030391*2021-07-17*16:39:09*39.90",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-07-17T13:12:34.000Z"
}, {
    "amount": 2051,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-07-28T13:13:49.000Z"
}, {
    "amount": 4530,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-02T13:14:20.000Z"
}, {
    "amount": 5780,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-02T13:14:44.000Z"
}, {
    "amount": 1633,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-04T13:15:40.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За юни",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-06T12:55:53.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-08-06T13:00:27.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-06T12:56:51.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "rent",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-06T13:00:17.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "bills",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-06T12:58:16.000Z"
}, {
    "amount": 2268,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-06T13:33:16.000Z"
}, {
    "amount": 3295,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-08T13:33:53.000Z"
}, {
    "amount": 800,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Taxi to Walltopia",
    "category": {
        "type": "credit",
        "name": "Транспорт",
        "id": "6273a1b741cfb9d40ff5e940",
        "hex": "#61708c",
        "icon": `${process.env.FRONTEND_URL}/img/icons/transport.svg`
    },
    "createdAt": "2021-08-09T00:47:47.000Z"
}, {
    "amount": 3378,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-11T02:56:53.000Z"
}, {
    "amount": 8642,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-12T02:56:30.000Z"
}, {
    "amount": 10000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Happy",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-14T14:13:04.000Z"
}, {
    "amount": 976,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-14T14:13:24.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "rent",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-16T13:19:13.000Z"
}, {
    "amount": 40000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "bills",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-16T13:19:23.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "за юли",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-16T13:19:43.000Z"
}, {
    "amount": 80000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #rent",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-08-16T13:20:06.000Z"
}, {
    "amount": 40000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване в In Cash Utility Fond #bills",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-16T13:20:20.000Z"
}, {
    "amount": 2318,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-16T14:14:10.000Z"
}, {
    "amount": 3507,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-17T14:13:47.000Z"
}, {
    "amount": 1476,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-18T14:15:14.000Z"
}, {
    "amount": 3042,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-19T15:28:26.000Z"
}, {
    "amount": 4786,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Gladen.bg Weetabix",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-20T10:27:29.000Z"
}, {
    "amount": 587,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4С София Вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:13:41.000Z"
}, {
    "amount": 2222,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4С София Ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:14:10.000Z"
}, {
    "amount": 673,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чербето Ток",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:15:05.000Z"
}, {
    "amount": 1699,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 интернет",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:15:39.000Z"
}, {
    "amount": 1099,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефон",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:15:58.000Z"
}, {
    "amount": 1099,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "А1 телефон",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:16:42.000Z"
}, {
    "amount": 2878,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Виваком",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-20T02:17:05.000Z"
}, {
    "amount": 1096,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-20T02:18:49.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-08-21T02:19:15.000Z"
}, {
    "amount": 3406,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-22T11:29:28.000Z"
}, {
    "amount": 8500,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Takeaway",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-08-29T14:13:39.000Z"
}, {
    "amount": 870900,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-08-30T21:00:00.000Z"
}, {
    "amount": 114600,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-08-30T21:00:00.000Z"
}, {
    "amount": 45000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Peter parse",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-08-29T21:00:00.000Z"
}, {
    "amount": 170000,
    "currency": "BGN",
    "walletID": "6273af17cc74d3185aa55eac",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": "Richi Rich",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7a03b186ea4bce77c",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-08-31T21:00:00.000Z"
}, {
    "amount": 1000,
    "currency": "EUR",
    "walletID": "6273af1767ed6544c5c75589",
    "userID": "6273a0733d3f7b2af9320b24",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b75d90ae1cb86925bf",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-08-31T21:00:00.000Z",
    "otherCurrency": {"amount": 1950, "currency": "BGN", "rate": 1.961276}
}, {
    "amount": 2090,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-01T21:00:00.000Z"
}, {
    "amount": 120000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За август",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-09-01T21:00:00.000Z"
}, {
    "amount": 230000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За август",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-09-01T21:00:00.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2021-09-19T21:00:00.000Z"
}, {
    "amount": 9750,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4 бутилки вода, риба, салати и супи",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-01T21:00:00.000Z"
}, {
    "amount": 3400,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Leo pizza",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-02T21:00:00.000Z"
}, {
    "amount": 7363,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-04T21:00:00.000Z"
}, {
    "amount": 7557,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Fun stuff",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-09-06T21:00:00.000Z"
}, {
    "amount": 258,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "CBA",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-06T21:00:00.000Z"
}, {
    "amount": 150000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "founded inside laptop bag",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-09-07T21:00:00.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "founded inside the gym shorts",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-09-09T21:00:00.000Z"
}, {
    "amount": 4000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Чебето пазаруване",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-09T21:00:00.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-10T21:00:00.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Септември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-09-30T21:00:00.000Z"
}, {
    "amount": 4490,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-09-26T21:00:00.000Z"
}, {
    "amount": 2894,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-10-01T21:00:00.000Z"
}, {
    "amount": 313,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-10-01T21:00:00.000Z"
}, {
    "amount": 1782,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Pills",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2021-09-23T21:00:00.000Z"
}, {
    "amount": 296,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Life - грозде",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-10-02T21:00:00.000Z"
}, {
    "amount": 500,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2021-10-03T21:00:00.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Октомври",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-10-17T21:00:00.000Z"
}, {
    "amount": 41500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "продаване на светкавиците и софтбок-ите",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-10-18T21:00:00.000Z"
}, {
    "amount": 304300,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "...",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-11-01T22:00:00.000Z"
}, {
    "amount": 42500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Приравняване",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-01T22:00:00.000Z"
}, {
    "amount": 55000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "OLX mic",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-01T22:00:00.000Z"
}, {
    "amount": 124000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "iPhone 12 mini",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-02T22:00:00.000Z"
}, {
    "amount": 74900,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Apple Watch Nike S6 40mm",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-01T22:00:00.000Z"
}, {
    "amount": 3171,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "fireship.io one month",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-01T22:00:00.000Z"
}, {
    "amount": 250,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "месечна такса",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-10-31T22:00:00.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Захранване на сметка",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-04T22:00:00.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Захранване на сметка",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-04T22:00:00.000Z"
}, {
    "amount": 5400,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lifesum годишен абонамент",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2021-11-04T22:00:00.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Ноември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-12-07T22:00:00.000Z"
}, {
    "amount": 121000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-12-20T22:00:00.000Z"
}, {
    "amount": 350000,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Декември",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2021-12-20T22:00:00.000Z"
}, {
    "amount": 202100,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-12-20T22:00:00.000Z"
}, {
    "amount": 2640,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Плавници от декатлон",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-12-19T22:00:00.000Z"
}, {
    "amount": 4369,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2021-11-30T22:00:00.000Z"
}, {
    "amount": 448,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2021-12-20T22:00:00.000Z"
}, {
    "amount": 15000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Umami",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-12-21T22:00:00.000Z"
}, {
    "amount": 3100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Deserts",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-12-21T22:00:00.000Z"
}, {
    "amount": 12035,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2021-12-28T22:00:00.000Z"
}, {
    "amount": 2800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cinema: Spider-men",
    "category": {
        "type": "credit",
        "name": "Забавления",
        "id": "6273a1b75f1ef59bd22fae00",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/entertainment.svg`
    },
    "createdAt": "2021-12-28T22:00:00.000Z"
}, {
    "amount": 1800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Cinema popcorn",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2021-12-28T22:00:00.000Z"
}, {
    "amount": 87500,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "първата седмица на януари",
    "category": {
        "type": "debit",
        "name": "Заплата",
        "id": "6273a1b7fc756e7f8669c5a2",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-01-20T22:00:00.000Z"
}, {
    "amount": 437546,
    "currency": "BGN",
    "walletID": "6273af17e3e50dfafa2f2940",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Преместване",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2022-02-09T22:00:00.000Z"
}, {
    "amount": 56200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2022-02-09T22:00:00.000Z"
}, {
    "amount": 10061,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-02-09T22:00:00.000Z"
}, {
    "amount": 8640,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "4xCreatine Monohydrate - 227 гр",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2022-02-09T22:00:00.000Z"
}, {
    "amount": 3957,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-09T22:00:00.000Z"
}, {
    "amount": 1784,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Bills",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-10T22:00:00.000Z"
}, {
    "amount": 6615,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-11T22:00:00.000Z"
}, {
    "amount": 4500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-02-12T22:00:00.000Z"
}, {
    "amount": 4480,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-13T22:00:00.000Z"
}, {
    "amount": 5200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-02-13T22:00:00.000Z"
}, {
    "amount": 718,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-16T22:00:00.000Z"
}, {
    "amount": 229,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-17T22:00:00.000Z"
}, {
    "amount": 6138,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-19T22:00:00.000Z"
}, {
    "amount": 4370,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-20T22:00:00.000Z"
}, {
    "amount": 3973,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-22T22:00:00.000Z"
}, {
    "amount": 3824,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-02-26T22:00:00.000Z"
}, {
    "amount": 2489,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-02T22:00:00.000Z"
}, {
    "amount": 1800,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Подарък за бейб",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-07T22:00:00.000Z"
}, {
    "amount": 6100,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Subway",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-03-08T22:00:00.000Z"
}, {
    "amount": 40000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Logitech keyboard and mouse",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-03-11T22:00:00.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-03-19T22:00:00.000Z"
}, {
    "amount": 211700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2022-03-19T22:00:00.000Z"
}, {
    "amount": 7343,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-22T22:00:00.000Z"
}, {
    "amount": 145000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Filcab first half",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-03-23T22:00:00.000Z"
}, {
    "amount": 145000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Filcab second half",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-03-23T22:00:00.000Z"
}, {
    "amount": 118,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-03-22T22:00:00.000Z"
}, {
    "amount": 10702,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-23T22:00:00.000Z"
}, {
    "amount": 5200,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Fireship pro ... has not be canceled",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-03-25T22:00:00.000Z"
}, {
    "amount": 398,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Strawberries",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-26T22:00:00.000Z"
}, {
    "amount": 1700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Miral dunars",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-27T21:00:00.000Z"
}, {
    "amount": 9018,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "LegionRun",
    "category": {
        "type": "credit",
        "name": "Спорт",
        "id": "6273a1b743e703a8192f06b8",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/gym.svg`
    },
    "createdAt": "2022-03-27T21:00:00.000Z"
}, {
    "amount": 878,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-28T21:00:00.000Z"
}, {
    "amount": 3000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Glovo Mimas",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-03-28T21:00:00.000Z"
}, {
    "amount": 2479,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Lidl",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-03-27T21:00:00.000Z"
}, {
    "amount": 102500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "not good",
    "category": {
        "type": "credit",
        "name": "Приравняване",
        "id": "6273a1b70692bd104073be61",
        "hex": "#f5534b",
        "icon": `${process.env.FRONTEND_URL}/img/icons/wallet.svg`
    },
    "createdAt": "2022-04-12T21:00:00.000Z"
}, {
    "amount": 203,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-04-12T21:00:00.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Наем",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-04-19T21:00:00.000Z"
}, {
    "amount": 1496,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-13T21:00:00.000Z"
}, {
    "amount": 4495,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-16T21:00:00.000Z"
}, {
    "amount": 270,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-17T21:00:00.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Transfer to card",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-04-17T21:00:00.000Z"
}, {
    "amount": 1116,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-18T21:00:00.000Z"
}, {
    "amount": 9500,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Italian Restaurant",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-04-18T21:00:00.000Z"
}, {
    "amount": 141,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-04-19T21:00:00.000Z"
}, {
    "amount": 30000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-04-17T21:00:00.000Z"
}, {
    "amount": 8000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2022-04-19T21:00:00.000Z"
}, {
    "amount": 70000,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": null,
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-04-20T21:00:00.000Z"
}, {
    "amount": 70000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Transfer to card",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-04-20T21:00:00.000Z"
}, {
    "amount": 63743,
    "currency": "BGN",
    "walletID": "6273af17d6da08ae55a4e478",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "London tickets",
    "category": {
        "type": "credit",
        "name": "Пътешествия",
        "id": "6273a1b7e7196c377f9adc33",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/plane.svg`
    },
    "createdAt": "2022-04-20T21:00:00.000Z"
}, {
    "amount": 1751,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-20T21:00:00.000Z"
}, {
    "amount": 6306,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-04-26T21:00:00.000Z"
}, {
    "amount": 11382,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-01T21:00:00.000Z"
}, {
    "amount": 23340,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Обръщане в паунд",
    "category": {
        "type": "credit",
        "name": "Пътешествия",
        "id": "6273a1b7e7196c377f9adc33",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/plane.svg`
    },
    "createdAt": "2022-05-01T21:00:00.000Z"
}, {
    "amount": 14985,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Superhosting",
    "category": {
        "type": "credit",
        "name": "Сметки",
        "id": "6273a1b7aab68cf6f25c2d05",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/money.svg`
    },
    "createdAt": "2022-05-02T21:00:00.000Z"
}, {
    "amount": 4478,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-02T21:00:00.000Z"
}, {
    "amount": 965,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Billa",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-02T21:00:00.000Z"
}, {
    "amount": 2000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Цветарски магазин",
    "category": {
        "type": "credit",
        "name": "Пазаруване",
        "id": "6273a1b7f2a7b83ba6f58ab5",
        "hex": "#5dc6ad",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-05-13T21:00:00.000Z"
}, {
    "amount": 1700,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Сироп за бейб",
    "category": {
        "type": "credit",
        "name": "Здраве",
        "id": "6273a1b7ef84d07e5ee3bc6b",
        "hex": "#e56274",
        "icon": `${process.env.FRONTEND_URL}/img/icons/healthcare.svg`
    },
    "createdAt": "2022-05-13T21:00:00.000Z"
}, {
    "amount": 1400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фантастико",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-13T21:00:00.000Z"
}, {
    "amount": 7513,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-17T21:00:00.000Z"
}, {
    "amount": 3693,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-18T21:00:00.000Z"
}, {
    "amount": 50444,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "София<->Истанбул",
    "category": {
        "type": "credit",
        "name": "Пътешествия",
        "id": "6273a1b7e7196c377f9adc33",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/plane.svg`
    },
    "createdAt": "2022-05-18T21:00:00.000Z"
}, {
    "amount": 6000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Банско хотел",
    "category": {
        "type": "credit",
        "name": "Хотели",
        "id": "6273a1b7b162dfc06894be13",
        "hex": "#47a7e6",
        "icon": `${process.env.FRONTEND_URL}/img/icons/acommodation.svg`
    },
    "createdAt": "2022-05-20T21:00:00.000Z"
}, {
    "amount": 5400,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Банско ресторант",
    "category": {
        "type": "credit",
        "name": "Заведения",
        "id": "6273a1b7b29f59e3aec037be",
        "hex": "#f963a0",
        "icon": `${process.env.FRONTEND_URL}/img/icons/food.svg`
    },
    "createdAt": "2022-05-20T21:00:00.000Z"
}, {
    "amount": 8404,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-23T21:00:00.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Май месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2022-05-23T11:52:28.000Z"
}, {
    "amount": 3172,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-24T21:00:00.000Z"
}, {
    "amount": 200,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Фитнес Флайс вода",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-26T21:00:00.000Z"
}, {
    "amount": 60000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Filcab",
    "category": {
        "type": "debit",
        "name": "Extra",
        "id": "6273a1b793f0a5ab2c4c98ae",
        "hex": "#ffa200",
        "icon": `${process.env.FRONTEND_URL}/img/icons/shopping.svg`
    },
    "createdAt": "2022-05-27T21:00:00.000Z"
}, {
    "amount": 2699,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-30T21:00:00.000Z"
}, {
    "amount": 5031,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "Билла",
    "category": {
        "type": "credit",
        "name": "Храна",
        "id": "6273a1b7e6330d4afc010683",
        "hex": "#b47b55",
        "icon": `${process.env.FRONTEND_URL}/img/icons/grocery.svg`
    },
    "createdAt": "2022-05-31T21:00:00.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юни месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2022-06-23T11:52:28.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Юли месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2022-07-23T11:52:28.000Z"
}, {
    "amount": 82000,
    "currency": "BGN",
    "walletID": "6273af170df0dfbaacd24235",
    "userID": "6273a061a5d8d48855ff4b6e",
    "note": "За Август месец",
    "category": {
        "type": "credit",
        "name": "Наем",
        "id": "6273a1b79c10d47371278253",
        "hex": "#71c643",
        "icon": `${process.env.FRONTEND_URL}/img/icons/rent.svg`
    },
    "createdAt": "2022-08-23T11:52:28.000Z"
}]